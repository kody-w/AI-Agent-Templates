---
name: encountertranscription
description: Tracks encounter recordings (voice dictation or ambient AI listening) and their real-time speech-to-text transcripts with speaker-role identification and confidence. Encounter records live in Microsoft Dataverse. Identify encounters by NATURAL reference: a clinician, a patient, or an ENC- reference; never ask for internal identifiers. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# EncounterTranscription skill

## When to use

- Show Encounter Transcription for encounterref ENC-8801.
- Which encounters were recorded today?
- Did any transcriptions fail?

## Rules (single source of truth)

- The bundled `encounter_transcription_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_encountertranscription`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs or deep links. Refer to records by their plain reference (e.g. ENC-8801) only. Synthetic demo data - never real clinical records. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `encounterRef` — Encounter ENC- reference, patient, or clinician name, e.g. ENC-8801 or 'Dr Amara Osei'. Pass the word: list to see today's recordings - never ask the user for an id.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_encountertranscription` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 encounter_transcription_agent.py --data-json '{"_CANON": <items from list_encountertranscription>}' --kwargs-json '{"encounterRef": "ENC-8801 or 'Dr Amara Osei"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `ENC-8801`.

"""Clinical Note Structuring & ICD/CPT Code Suggestion — steps 3-4 of the
Clinical Documentation & Coding Automation process flow.

Step 3 — Clinical Note Structuring: The transcript is structured into SOAP
format (Subjective, Objective, Assessment, Plan) and key clinical entities
extracted: diagnoses, medications, procedures. (Azure OpenAI)

Step 4 — ICD & CPT Code Suggestion: Extracted clinical entities are matched
against ICD-10 and CPT code libraries, suggesting the most accurate codes
with confidence scores. (Copilot Studio, Azure AI, Clinical Coding
Libraries)

Identify notes by NATURAL reference (patient, clinician, or ENC-
reference). Data home: Microsoft Dataverse. Synthetic demo data — never
real clinical coding advice.
"""
try:
    from agents.basic_agent import BasicAgent
except ImportError:
    class BasicAgent:
        def __init__(self, name, metadata):
            self.name, self.metadata = name, metadata

_CANON = []  # data arrives at runtime from the MCP server (--data-json); the connector is the single source of truth


class SoapCodingSuggestion(BasicAgent):
    CAPIR = {"binding": {"system": "Microsoft Dataverse", "table": "accounts"}}
    TRIGGERS = [
        "Show Soap Coding Suggestion for encounterref ENC-8804.",
        "What codes were suggested for Grace Holt's encounter?",
        "Which notes are structured and ready for review?",
    ]
    RESPONSE = ("Present records as plain text fields. NEVER invent, guess, "
                "or fabricate URLs or deep links. Refer to records by their "
                "plain reference (e.g. ENC-8801) only. Synthetic demo data - "
                "never real clinical coding advice. Keep answers under ~120 "
                "words, professional markdown, no emojis.")
    SYNTHETIC_DATA = list(_CANON)

    def __init__(self):
        self.name = "SoapCodingSuggestion"
        self.metadata = {
            "name": self.name,
            "description": (
                "Holds each encounter's SOAP-structured note (subjective, "
                "objective, assessment, plan) with extracted clinical "
                "entities, and the suggested ICD-10 and CPT codes with "
                "confidence scores matched from the coding libraries. "
                "Notes live in Microsoft Dataverse. Identify notes by "
                "NATURAL reference: a patient, clinician, or ENC- "
                "reference; 'list' shows every structured note."),
            "parameters": {
                "type": "object",
                "properties": {
                    "encounterRef": {
                        "type": "string",
                        "description": ("Encounter ENC- reference or "
                                        "patient name, e.g. ENC-8804 or "
                                        "'Marcus Reid'. Pass the word: "
                                        "list to see every structured "
                                        "note - never ask the user for "
                                        "an id.")},
                },
                "required": [],
            },
        }
        super().__init__(self.name, self.metadata)

    def perform(self, **kwargs):
        ref = str(kwargs.get("encounterRef") or "").strip()
        low = ref.lower()
        if not ref or low == "list":
            lines = ["## Structured notes with code suggestions"]
            lines += [f"{i}. **{n['encounterRef']}** {n['patientName']} — "
                      f"{n['soapAssessment']} — ICD: "
                      f"{n['icdSuggestions'].split(' ')[0]}"
                      for i, n in enumerate(_CANON, 1)]
            lines.append("")
            lines.append("Open a note for the full SOAP structure and code "
                         "suggestions. ENC-8805 has no note yet (recording "
                         "failed - re-dictation pending).")
            return "\n".join(lines)
        hits = [n for n in _CANON if low == n["encounterRef"].lower()
                or low in n["patientName"].lower()]
        if not hits:
            return (f"No structured note matches `{ref}`. Say 'list' for "
                    "every note (ENC-8805 is pending re-dictation).")
        n = hits[0]
        return "\n".join([
            f"## {n['encounterRef']} — {n['patientName']}",
            f"- SOAP assessment: {n['soapAssessment']}",
            f"- Extracted entities: {n['extractedEntities']}",
            f"- ICD-10 suggestions: {n['icdSuggestions']}",
            f"- CPT suggestions: {n['cptSuggestions']}",
            "",
            f"Next: clinician review and approval for "
            f"{n['encounterRef']}.",
        ])


if __name__ == "__main__":  # thin-skill entrypoint (generated)
    import argparse as _ap
    import json as _js
    import sys as _sys
    _p = _ap.ArgumentParser(description="Run the SoapCodingSuggestion capability on "
                                        "records fetched from the MCP server.")
    _p.add_argument("--data-json", default="{}",
                    help="JSON object mapping dataset names to record arrays "
                         "fetched from the MCP server, e.g. "
                         "'{\"_CANON\": <items from list_soapcodingsuggestion>}'")
    _p.add_argument("--kwargs-json", default="{}",
                    help="JSON object of perform() keyword arguments.")
    _a = _p.parse_args()
    try:
        _data = _js.loads(_a.data_json)
        _kw = _js.loads(_a.kwargs_json)
    except Exception as _e:
        print("Invalid JSON argument: %s" % _e)
        _sys.exit(2)
    _g = globals()
    for _name, _rows in (_data or {}).items():
        if _name in _g and isinstance(_rows, (list, dict)):
            _g[_name] = _rows
        for _obj in list(_g.values()):
            if isinstance(_obj, type) and hasattr(_obj, _name):
                setattr(_obj, _name, _rows)
    def _have(_n):
        if _g.get(_n):
            return True
        return any(isinstance(_o, type) and getattr(_o, _n, None)
                   for _o in list(_g.values()))
    _missing = [n for n in ['_CANON'] if not _have(n)]
    if _missing:
        print("No data provided for: %s. Fetch records from the MCP server "
              "(list_soapcodingsuggestion) first and pass them via --data-json."
              % ", ".join(_missing))
        _sys.exit(3)
    print(SoapCodingSuggestion().perform(**_kw))

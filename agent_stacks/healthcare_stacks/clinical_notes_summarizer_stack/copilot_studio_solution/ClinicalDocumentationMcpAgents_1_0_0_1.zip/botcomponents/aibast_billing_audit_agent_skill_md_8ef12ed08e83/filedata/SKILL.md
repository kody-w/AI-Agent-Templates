---
name: billingaudittrail
description: Tracks charge capture into the Revenue Cycle Management system (claims generated from approved CPT codes with documentation attached) and the immutable audit trail of every AI suggestion, clinician acceptance or override, and system action. Records live in Microsoft Dataverse. Identify items by NATURAL reference: a CLM-, AUD-, or ENC- reference or a patient name; 'list' shows claims and audit entries. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# BillingAuditTrail skill

## When to use

- Show Billing Audit Trail for claimref CLM-3301.
- Which claims went to the payer today?
- Show me the audit trail for ENC-8802

## Rules (single source of truth)

- The bundled `billing_audit_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_billingaudittrail`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs or deep links. Refer to records by their plain reference (e.g. CLM-3301) only. Synthetic demo data. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `claimRef` — Claim CLM-, audit AUD-, encounter ENC- reference, or patient name, e.g. CLM-3301 or 'Grace Holt'. Pass the word: list to see every claim and audit entry - never ask the user for an id.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_billingaudittrail` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 billing_audit_agent.py --data-json '{"_CLAIMS": <items from list_billingaudittrail>}' --kwargs-json '{"claimRef": "CLM-3301 or 'Grace Holt'. Pa"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `CLM-3301`.

---
name: soapcodingsuggestion
description: Holds each encounter's SOAP-structured note (subjective, objective, assessment, plan) with extracted clinical entities, and the suggested ICD-10 and CPT codes with confidence scores matched from the coding libraries. Notes live in Microsoft Dataverse. Identify notes by NATURAL reference: a patient, clinician, or ENC- reference; 'list' shows every structured note. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# SoapCodingSuggestion skill

## When to use

- Show Soap Coding Suggestion for encounterref ENC-8804.
- What codes were suggested for Grace Holt's encounter?
- Which notes are structured and ready for review?

## Rules (single source of truth)

- The bundled `soap_coding_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_soapcodingsuggestion`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs or deep links. Refer to records by their plain reference (e.g. ENC-8801) only. Synthetic demo data - never real clinical coding advice. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `encounterRef` — Encounter ENC- reference or patient name, e.g. ENC-8804 or 'Marcus Reid'. Pass the word: list to see every structured note - never ask the user for an id.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_soapcodingsuggestion` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 soap_coding_agent.py --data-json '{"_CANON": <items from list_soapcodingsuggestion>}' --kwargs-json '{"encounterRef": "ENC-8804 or 'Marcus Reid'. P"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `ENC-8801`.

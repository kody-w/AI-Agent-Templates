---
name: reviewwriteback
description: Tracks clinician review and approval of structured notes and suggested codes (approve as-is, amend, or override) and the automatic EHR write-back of approved notes. Review records live in Microsoft Dataverse. Identify encounters by NATURAL reference: a patient or ENC- reference; 'list' shows the review queue; recording an approval needs the clinician's explicit instruction. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# ReviewWriteback skill

## When to use

- Show Review Writeback for encounterref ENC-8804.
- Which notes are awaiting clinician review?
- Approve ENC-8804 as suggested

## Rules (single source of truth)

- The bundled `review_writeback_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_reviewwriteback`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs or deep links. Refer to records by their plain reference (e.g. ENC-8804) only. Synthetic demo data. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `encounterRef` — Encounter ENC- reference or patient name, e.g. ENC-8804 or 'Marcus Reid'. Pass the word: list to see the review queue - never ask the user for an id.
- `decision` — Clinician decision to record: approve or amend, with any amendment detail (optional).

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_reviewwriteback` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 review_writeback_agent.py --data-json '{"_CANON": <items from list_reviewwriteback>}' --kwargs-json '{"encounterRef": "ENC-8804 or 'Marcus Reid'. P"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `ENC-8801`.

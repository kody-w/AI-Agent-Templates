"""Charge Capture to Billing System + Audit Trail & Compliance Log — steps
7-8 of the Clinical Documentation & Coding Automation process flow.

Step 7 — Charge Capture to Billing System: Approved CPT codes and encounter
details pass to the Revenue Cycle Management system to generate the claim,
with supporting documentation attached. (Revenue Cycle Management, Power
Automate)

Step 8 — Audit Trail & Compliance Log: Every AI suggestion, clinician
acceptance or override, and system action is logged in an immutable audit
trail for compliance, quality, and training. (Azure Monitor, Power BI)

Claims cohere with the review agent: only APPROVED encounters carry
claims; the audit log records the exact accept/override actions. Data
home: Microsoft Dataverse. Synthetic demo data.
"""
try:
    from agents.basic_agent import BasicAgent
except ImportError:
    class BasicAgent:
        def __init__(self, name, metadata):
            self.name, self.metadata = name, metadata

_CLAIMS = []  # data arrives at runtime from the MCP server (--data-json); the connector is the single source of truth

_AUDIT = []  # data arrives at runtime from the MCP server (--data-json); the connector is the single source of truth


class BillingAuditTrail(BasicAgent):
    CAPIR = {"binding": {"system": "Microsoft Dataverse", "table": "accounts"}}
    TRIGGERS = [
        "Show Billing Audit Trail for claimref CLM-3301.",
        "Which claims went to the payer today?",
        "Show me the audit trail for ENC-8802",
    ]
    RESPONSE = ("Present records as plain text fields. NEVER invent, guess, "
                "or fabricate URLs or deep links. Refer to records by their "
                "plain reference (e.g. CLM-3301) only. Synthetic demo data. "
                "Keep answers under ~120 words, professional markdown, no "
                "emojis.")
    SYNTHETIC_DATA = _CLAIMS + _AUDIT

    def __init__(self):
        self.name = "BillingAuditTrail"
        self.metadata = {
            "name": self.name,
            "description": (
                "Tracks charge capture into the Revenue Cycle Management "
                "system (claims generated from approved CPT codes with "
                "documentation attached) and the immutable audit trail of "
                "every AI suggestion, clinician acceptance or override, "
                "and system action. Records live in Microsoft Dataverse. "
                "Identify items by NATURAL reference: a CLM-, AUD-, or "
                "ENC- reference or a patient name; 'list' shows claims "
                "and audit entries."),
            "parameters": {
                "type": "object",
                "properties": {
                    "claimRef": {
                        "type": "string",
                        "description": ("Claim CLM-, audit AUD-, encounter "
                                        "ENC- reference, or patient name, "
                                        "e.g. CLM-3301 or 'Grace Holt'. "
                                        "Pass the word: list to see every "
                                        "claim and audit entry - never "
                                        "ask the user for an id.")},
                },
                "required": [],
            },
        }
        super().__init__(self.name, self.metadata)

    def perform(self, **kwargs):
        ref = str(kwargs.get("claimRef") or "").strip()
        low = ref.lower()
        if not ref or low == "list":
            lines = ["## Claims (Revenue Cycle Management)"]
            lines += [f"{i}. **{c['claimRef']}** ({c['encounterRef']}, "
                      f"{c['patientName']}) — {c['claimLines']} — "
                      f"${c['claimAmount']:,.2f} — {c['claimStatus'][:44]}"
                      for i, c in enumerate(_CLAIMS, 1)]
            lines += ["", "## Audit trail (immutable)"]
            lines += [f"- **{a['auditRef']}** ({a['encounterRef']}): "
                      f"{a['auditAction']}" for a in _AUDIT]
            return "\n".join(lines)
        c = next((c for c in _CLAIMS if low in (c["claimRef"].lower(),
                                                c["encounterRef"].lower())
                  or low in c["patientName"].lower()), None)
        a = next((a for a in _AUDIT if low in (a["auditRef"].lower(),
                                               a["encounterRef"].lower())), None)
        if not c and not a:
            return (f"No claim or audit entry matches `{ref}`. Say 'list' "
                    "for everything.")
        lines = []
        if c:
            lines += [f"## Claim {c['claimRef']} — {c['patientName']} "
                      f"({c['encounterRef']})",
                      f"- Lines: {c['claimLines']} | Amount: "
                      f"${c['claimAmount']:,.2f}",
                      f"- Status: {c['claimStatus']}",
                      f"- Documentation: {c['documentation']}"]
        if a:
            lines += ["", f"## Audit {a['auditRef']} ({a['encounterRef']})",
                      f"- {a['auditAction']}"]
        return "\n".join(lines)


if __name__ == "__main__":  # thin-skill entrypoint (generated)
    import argparse as _ap
    import json as _js
    import sys as _sys
    _p = _ap.ArgumentParser(description="Run the BillingAuditTrail capability on "
                                        "records fetched from the MCP server.")
    _p.add_argument("--data-json", default="{}",
                    help="JSON object mapping dataset names to record arrays "
                         "fetched from the MCP server, e.g. "
                         "'{\"_CLAIMS\": <items from list_billingaudittrail>}'")
    _p.add_argument("--kwargs-json", default="{}",
                    help="JSON object of perform() keyword arguments.")
    _a = _p.parse_args()
    try:
        _data = _js.loads(_a.data_json)
        _kw = _js.loads(_a.kwargs_json)
    except Exception as _e:
        print("Invalid JSON argument: %s" % _e)
        _sys.exit(2)
    _g = globals()
    for _name, _rows in (_data or {}).items():
        if _name in _g and isinstance(_rows, (list, dict)):
            _g[_name] = _rows
        for _obj in list(_g.values()):
            if isinstance(_obj, type) and hasattr(_obj, _name):
                setattr(_obj, _name, _rows)
    def _have(_n):
        if _g.get(_n):
            return True
        return any(isinstance(_o, type) and getattr(_o, _n, None)
                   for _o in list(_g.values()))
    _missing = [n for n in ['_CLAIMS', '_AUDIT'] if not _have(n)]
    if _missing:
        print("No data provided for: %s. Fetch records from the MCP server "
              "(list_billingaudittrail) first and pass them via --data-json."
              % ", ".join(_missing))
        _sys.exit(3)
    print(BillingAuditTrail().perform(**_kw))

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

public class Script : ScriptBase
{
    private static readonly McpServerOptions Options = new McpServerOptions
    {
        ServerInfo = new McpServerInfo
        {
            Name = "clinical-documentation-mcp",
            Version = "1.0.0",
            Title = "Clinical Documentation & Coding",
            Description = "Inline MCP server carrying the synthetic Clinical Documentation & Coding dataset. No external hosting; every tool answers from embedded data."
        },
        ProtocolVersion = "2025-11-25",
        Capabilities = new McpCapabilities { Tools = true },
        Instructions = @"This MCP server carries the complete synthetic Clinical Documentation & Coding dataset. Call list_* first when the user gives no identifier — never ask for an internal id; every record is on this server. get_billingaudittrail / list_billingaudittrail serve: Tracks charge capture into the Revenue Cycle Management system (claims generated from approved CPT codes with documentation attached) and the immutable audit tr get_encountertranscription / list_encountertranscription serve: Tracks encounter recordings (voice dictation or ambient AI listening) and their real-time speech-to-text transcripts with speaker-role identification and confid get_reviewwriteback / list_reviewwriteback serve: Tracks clinician review and approval of structured notes and suggested codes (approve as-is, amend, or override) and the automatic EHR write-back of approved no get_soapcodingsuggestion / list_soapcodingsuggestion serve: Holds each encounter's SOAP-structured note (subjective, objective, assessment, plan) with extracted clinical entities, and the suggested ICD-10 and CPT codes w"
    };

    public override async Task<HttpResponseMessage> ExecuteAsync()
    {
        var handler = new McpRequestHandler(Options);
        RegisterCapabilities(handler);
        var body = await this.Context.Request.Content.ReadAsStringAsync().ConfigureAwait(false);
        var result = await handler.HandleAsync(body, this.CancellationToken).ConfigureAwait(false);
        return new HttpResponseMessage(HttpStatusCode.OK)
        { Content = new StringContent(result, Encoding.UTF8, "application/json") };
    }

    private static readonly JArray Data_BillingAuditTrail = JArray.Parse(@"[
  {
    ""claimRef"": ""CLM-3301"",
    ""encounterRef"": ""ENC-8801"",
    ""patientName"": ""Grace Holt"",
    ""claimLines"": ""99214 + 93000"",
    ""claimAmount"": 312.0,
    ""claimStatus"": ""submitted to payer"",
    ""documentation"": ""SOAP note + ECG report attached""
  },
  {
    ""claimRef"": ""CLM-3302"",
    ""encounterRef"": ""ENC-8802"",
    ""patientName"": ""Omar Haddad"",
    ""claimLines"": ""99212 + 73600"",
    ""claimAmount"": 198.5,
    ""claimStatus"": ""submitted to payer (amended code 99212 per clinician override)"",
    ""documentation"": ""SOAP note + x-ray order attached""
  },
  {
    ""claimRef"": ""CLM-3303"",
    ""encounterRef"": ""ENC-8803"",
    ""patientName"": ""Lena Novak"",
    ""claimLines"": ""99212 + 87880"",
    ""claimAmount"": 121.75,
    ""claimStatus"": ""submitted to payer"",
    ""documentation"": ""SOAP note + rapid strep result attached""
  },
  {
    ""auditRef"": ""AUD-9101"",
    ""encounterRef"": ""ENC-8801"",
    ""auditAction"": ""AI suggested I20.9/I10 + 99214/93000; clinician accepted all (one-click)""
  },
  {
    ""auditRef"": ""AUD-9102"",
    ""encounterRef"": ""ENC-8802"",
    ""auditAction"": ""AI suggested 99213; clinician OVERRODE to 99212 - override reason captured for model training""
  },
  {
    ""auditRef"": ""AUD-9103"",
    ""encounterRef"": ""ENC-8803"",
    ""auditAction"": ""AI suggested J02.9 + 99212/87880; clinician accepted all (one-click)""
  },
  {
    ""auditRef"": ""AUD-9104"",
    ""encounterRef"": ""ENC-8804"",
    ""auditAction"": ""AI suggestions issued; awaiting clinician review - no claim generated yet""
  }
]");
    private static readonly JArray Data_EncounterTranscription = JArray.Parse(@"[
  {
    ""encounterRef"": ""ENC-8801"",
    ""patientName"": ""Grace Holt"",
    ""clinicianName"": ""Dr Amara Osei"",
    ""captureMode"": ""ambient AI listening"",
    ""durationMinutes"": 14,
    ""transcriptStatus"": ""transcribed - speakers identified (clinician/patient), 98.4% confidence""
  },
  {
    ""encounterRef"": ""ENC-8802"",
    ""patientName"": ""Omar Haddad"",
    ""clinicianName"": ""Dr Priya Nair"",
    ""captureMode"": ""voice dictation"",
    ""durationMinutes"": 6,
    ""transcriptStatus"": ""transcribed - single speaker, 99.1% confidence""
  },
  {
    ""encounterRef"": ""ENC-8803"",
    ""patientName"": ""Lena Novak"",
    ""clinicianName"": ""Dr Priya Nair"",
    ""captureMode"": ""ambient AI listening"",
    ""durationMinutes"": 9,
    ""transcriptStatus"": ""transcribed - speakers identified, 97.8% confidence""
  },
  {
    ""encounterRef"": ""ENC-8804"",
    ""patientName"": ""Marcus Reid"",
    ""clinicianName"": ""Dr Amara Osei"",
    ""captureMode"": ""ambient AI listening"",
    ""durationMinutes"": 22,
    ""transcriptStatus"": ""transcribed - 3 speakers (registrar present), 96.9% confidence""
  },
  {
    ""encounterRef"": ""ENC-8805"",
    ""patientName"": ""Ana Sousa"",
    ""clinicianName"": ""Dr Tomas Weber"",
    ""captureMode"": ""voice dictation"",
    ""durationMinutes"": 5,
    ""transcriptStatus"": ""RECORDING FAILED at 0:42 - clinician re-dictation requested""
  }
]");
    private static readonly JArray Data_ReviewWriteback = JArray.Parse(@"[
  {
    ""encounterRef"": ""ENC-8801"",
    ""patientName"": ""Grace Holt"",
    ""reviewStatus"": ""APPROVED as suggested"",
    ""reviewNote"": ""one-click approval - no amendments"",
    ""ehrWriteback"": ""written to EHR - longitudinal record updated""
  },
  {
    ""encounterRef"": ""ENC-8802"",
    ""patientName"": ""Omar Haddad"",
    ""reviewStatus"": ""APPROVED WITH AMENDMENT"",
    ""reviewNote"": ""clinician overrode CPT 99213 -> 99212 (visit complexity lower than suggested)"",
    ""ehrWriteback"": ""written to EHR - longitudinal record updated""
  },
  {
    ""encounterRef"": ""ENC-8803"",
    ""patientName"": ""Lena Novak"",
    ""reviewStatus"": ""APPROVED as suggested"",
    ""reviewNote"": ""one-click approval - no amendments"",
    ""ehrWriteback"": ""written to EHR - longitudinal record updated""
  },
  {
    ""encounterRef"": ""ENC-8804"",
    ""patientName"": ""Marcus Reid"",
    ""reviewStatus"": ""AWAITING REVIEW"",
    ""reviewNote"": ""high-complexity ED note queued for Dr Osei"",
    ""ehrWriteback"": ""pending clinician approval""
  }
]");
    private static readonly JArray Data_SoapCodingSuggestion = JArray.Parse(@"[
  {
    ""encounterRef"": ""ENC-8801"",
    ""patientName"": ""Grace Holt"",
    ""soapAssessment"": ""stable angina, hypertension review"",
    ""extractedEntities"": ""chest pain; GTN spray; ECG performed"",
    ""icdSuggestions"": ""I20.9 (angina pectoris, unspecified) conf 0.94; I10 (essential hypertension) conf 0.91"",
    ""cptSuggestions"": ""99214 (established patient, moderate) conf 0.92; 93000 (ECG with interpretation) conf 0.95""
  },
  {
    ""encounterRef"": ""ENC-8802"",
    ""patientName"": ""Omar Haddad"",
    ""soapAssessment"": ""lateral ankle sprain, rule out fracture"",
    ""extractedEntities"": ""ankle inversion injury; x-ray ordered; RICE advice"",
    ""icdSuggestions"": ""S93.401 (sprain of unspecified ligament, right ankle) conf 0.89"",
    ""cptSuggestions"": ""99213 (established patient, low-moderate) conf 0.93; 73600 (ankle x-ray, 2 views) conf 0.96""
  },
  {
    ""encounterRef"": ""ENC-8803"",
    ""patientName"": ""Lena Novak"",
    ""soapAssessment"": ""acute pharyngitis, viral"",
    ""extractedEntities"": ""sore throat; fever 37.9; rapid strep negative"",
    ""icdSuggestions"": ""J02.9 (acute pharyngitis, unspecified) conf 0.95"",
    ""cptSuggestions"": ""99212 (established patient, straightforward) conf 0.94; 87880 (rapid strep test) conf 0.97""
  },
  {
    ""encounterRef"": ""ENC-8804"",
    ""patientName"": ""Marcus Reid"",
    ""soapAssessment"": ""acute asthma exacerbation, moderate"",
    ""extractedEntities"": ""wheeze; salbutamol nebuliser; peak flow 55% predicted; prednisolone course"",
    ""icdSuggestions"": ""J45.901 (unspecified asthma with acute exacerbation) conf 0.96"",
    ""cptSuggestions"": ""99284 (ED visit, high complexity) conf 0.90; 94640 (nebuliser treatment) conf 0.95""
  }
]");

    private void RegisterCapabilities(McpRequestHandler handler)
    {
        handler.AddTool("list_billingaudittrail",
            "List every record behind the BillingAuditTrail capability. Tracks charge capture into the Revenue Cycle Management system (claims generated from approved CPT codes with documentation attached) and the immutable audit trail of every AI suggestion, clinician ac Call with no arguments to see all records.",
            schemaConfig: s => s.String("filter", "Optional case-insensitive text filter matched against every field. Omit to return all records."),
            handler: async (args, ct) =>
            {
                var f = (args.Value<string>("filter") ?? "").Trim().ToLowerInvariant();
                if (string.IsNullOrEmpty(f))
                    return new JObject { ["count"] = Data_BillingAuditTrail.Count, ["items"] = JArray.Parse(Data_BillingAuditTrail.ToString()) };
                var hits = new JArray();
                foreach (var r in Data_BillingAuditTrail)
                    if (r.ToString().ToLowerInvariant().Contains(f)) hits.Add(r);
                if (hits.Count == 0)
                    return new JObject { ["message"] = "No BillingAuditTrail record matches \"" + f + "\". Call list_billingaudittrail with no filter to see every record." };
                return new JObject { ["count"] = hits.Count, ["items"] = hits };
            });
        handler.AddTool("get_billingaudittrail",
            "Look up ONE BillingAuditTrail record by its claimRef (case-insensitive; a partial match on any name field also works). Returns every field of the record.",
            schemaConfig: s => s.String("claimRef", "The record key, e.g. \"CLM-3301\". A person/company name also resolves.", required: true),
            handler: async (args, ct) =>
            {
                var id = (args.Value<string>("claimRef") ?? "").Trim();
                foreach (var r in Data_BillingAuditTrail)
                    if (string.Equals(r["claimRef"]?.ToString(), id, StringComparison.OrdinalIgnoreCase))
                        return (JObject)r.DeepClone();
                foreach (var r in Data_BillingAuditTrail)
                    if (r.ToString().ToLowerInvariant().Contains(id.ToLowerInvariant()) && id.Length >= 3)
                        return (JObject)r.DeepClone();
                throw new ArgumentException("No BillingAuditTrail record found for \"" + id + "\". Keys look like \"CLM-3301\"; call list_billingaudittrail to see every record.");
            });
        handler.AddTool("list_encountertranscription",
            "List every record behind the EncounterTranscription capability. Tracks encounter recordings (voice dictation or ambient AI listening) and their real-time speech-to-text transcripts with speaker-role identification and confidence. Encounter records live in Microsof Call with no arguments to see all records.",
            schemaConfig: s => s.String("filter", "Optional case-insensitive text filter matched against every field. Omit to return all records."),
            handler: async (args, ct) =>
            {
                var f = (args.Value<string>("filter") ?? "").Trim().ToLowerInvariant();
                if (string.IsNullOrEmpty(f))
                    return new JObject { ["count"] = Data_EncounterTranscription.Count, ["items"] = JArray.Parse(Data_EncounterTranscription.ToString()) };
                var hits = new JArray();
                foreach (var r in Data_EncounterTranscription)
                    if (r.ToString().ToLowerInvariant().Contains(f)) hits.Add(r);
                if (hits.Count == 0)
                    return new JObject { ["message"] = "No EncounterTranscription record matches \"" + f + "\". Call list_encountertranscription with no filter to see every record." };
                return new JObject { ["count"] = hits.Count, ["items"] = hits };
            });
        handler.AddTool("get_encountertranscription",
            "Look up ONE EncounterTranscription record by its encounterRef (case-insensitive; a partial match on any name field also works). Returns every field of the record.",
            schemaConfig: s => s.String("encounterRef", "The record key, e.g. \"ENC-8801\". A person/company name also resolves.", required: true),
            handler: async (args, ct) =>
            {
                var id = (args.Value<string>("encounterRef") ?? "").Trim();
                foreach (var r in Data_EncounterTranscription)
                    if (string.Equals(r["encounterRef"]?.ToString(), id, StringComparison.OrdinalIgnoreCase))
                        return (JObject)r.DeepClone();
                foreach (var r in Data_EncounterTranscription)
                    if (r.ToString().ToLowerInvariant().Contains(id.ToLowerInvariant()) && id.Length >= 3)
                        return (JObject)r.DeepClone();
                throw new ArgumentException("No EncounterTranscription record found for \"" + id + "\". Keys look like \"ENC-8801\"; call list_encountertranscription to see every record.");
            });
        handler.AddTool("list_reviewwriteback",
            "List every record behind the ReviewWriteback capability. Tracks clinician review and approval of structured notes and suggested codes (approve as-is, amend, or override) and the automatic EHR write-back of approved notes. Review records live in Microsoft Da Call with no arguments to see all records.",
            schemaConfig: s => s.String("filter", "Optional case-insensitive text filter matched against every field. Omit to return all records."),
            handler: async (args, ct) =>
            {
                var f = (args.Value<string>("filter") ?? "").Trim().ToLowerInvariant();
                if (string.IsNullOrEmpty(f))
                    return new JObject { ["count"] = Data_ReviewWriteback.Count, ["items"] = JArray.Parse(Data_ReviewWriteback.ToString()) };
                var hits = new JArray();
                foreach (var r in Data_ReviewWriteback)
                    if (r.ToString().ToLowerInvariant().Contains(f)) hits.Add(r);
                if (hits.Count == 0)
                    return new JObject { ["message"] = "No ReviewWriteback record matches \"" + f + "\". Call list_reviewwriteback with no filter to see every record." };
                return new JObject { ["count"] = hits.Count, ["items"] = hits };
            });
        handler.AddTool("get_reviewwriteback",
            "Look up ONE ReviewWriteback record by its encounterRef (case-insensitive; a partial match on any name field also works). Returns every field of the record.",
            schemaConfig: s => s.String("encounterRef", "The record key, e.g. \"ENC-8801\". A person/company name also resolves.", required: true),
            handler: async (args, ct) =>
            {
                var id = (args.Value<string>("encounterRef") ?? "").Trim();
                foreach (var r in Data_ReviewWriteback)
                    if (string.Equals(r["encounterRef"]?.ToString(), id, StringComparison.OrdinalIgnoreCase))
                        return (JObject)r.DeepClone();
                foreach (var r in Data_ReviewWriteback)
                    if (r.ToString().ToLowerInvariant().Contains(id.ToLowerInvariant()) && id.Length >= 3)
                        return (JObject)r.DeepClone();
                throw new ArgumentException("No ReviewWriteback record found for \"" + id + "\". Keys look like \"ENC-8801\"; call list_reviewwriteback to see every record.");
            });
        handler.AddTool("list_soapcodingsuggestion",
            "List every record behind the SoapCodingSuggestion capability. Holds each encounter's SOAP-structured note (subjective, objective, assessment, plan) with extracted clinical entities, and the suggested ICD-10 and CPT codes with confidence scores matched from the c Call with no arguments to see all records.",
            schemaConfig: s => s.String("filter", "Optional case-insensitive text filter matched against every field. Omit to return all records."),
            handler: async (args, ct) =>
            {
                var f = (args.Value<string>("filter") ?? "").Trim().ToLowerInvariant();
                if (string.IsNullOrEmpty(f))
                    return new JObject { ["count"] = Data_SoapCodingSuggestion.Count, ["items"] = JArray.Parse(Data_SoapCodingSuggestion.ToString()) };
                var hits = new JArray();
                foreach (var r in Data_SoapCodingSuggestion)
                    if (r.ToString().ToLowerInvariant().Contains(f)) hits.Add(r);
                if (hits.Count == 0)
                    return new JObject { ["message"] = "No SoapCodingSuggestion record matches \"" + f + "\". Call list_soapcodingsuggestion with no filter to see every record." };
                return new JObject { ["count"] = hits.Count, ["items"] = hits };
            });
        handler.AddTool("get_soapcodingsuggestion",
            "Look up ONE SoapCodingSuggestion record by its encounterRef (case-insensitive; a partial match on any name field also works). Returns every field of the record.",
            schemaConfig: s => s.String("encounterRef", "The record key, e.g. \"ENC-8801\". A person/company name also resolves.", required: true),
            handler: async (args, ct) =>
            {
                var id = (args.Value<string>("encounterRef") ?? "").Trim();
                foreach (var r in Data_SoapCodingSuggestion)
                    if (string.Equals(r["encounterRef"]?.ToString(), id, StringComparison.OrdinalIgnoreCase))
                        return (JObject)r.DeepClone();
                foreach (var r in Data_SoapCodingSuggestion)
                    if (r.ToString().ToLowerInvariant().Contains(id.ToLowerInvariant()) && id.Length >= 3)
                        return (JObject)r.DeepClone();
                throw new ArgumentException("No SoapCodingSuggestion record found for \"" + id + "\". Keys look like \"ENC-8801\"; call list_soapcodingsuggestion to see every record.");
            });
    }
}

// ║  SECTION 2: MCP FRAMEWORK                                                  ║
// ║                                                                            ║
// ║  Built-in McpRequestHandler that brings MCP C# SDK patterns to Power       ║
// ║  Platform. If Microsoft enables the official SDK namespaces, this section   ║
// ║  becomes a using statement instead of inline code.                          ║
// ║                                                                            ║
// ║  Spec coverage: MCP 2025-11-25                                             ║
// ║  Handles: initialize, ping, tools/*, resources/*, prompts/*,               ║
// ║           completion/complete, logging/setLevel, all notifications          ║
// ║                                                                            ║
// ║  Stateless limitations (Power Platform cannot send async notifications):   ║
// ║   - Tasks (experimental, requires persistent state between requests)       ║
// ║   - Server→client requests (sampling, elicitation, roots/list)             ║
// ║   - Server→client notifications (progress, logging/message, list_changed)  ║
// ║                                                                            ║
// ║  Do not modify unless extending the framework itself.                      ║
// ╚══════════════════════════════════════════════════════════════════════════════╝

// ── Configuration Types ──────────────────────────────────────────────────────

/// <summary>Server identity reported in initialize response.</summary>
public class McpServerInfo
{
    public string Name { get; set; } = "mcp-server";
    public string Version { get; set; } = "1.0.0";
    public string Title { get; set; }
    public string Description { get; set; }
}

/// <summary>Capabilities declared during initialization.</summary>
public class McpCapabilities
{
    public bool Tools { get; set; } = true;
    public bool Resources { get; set; }
    public bool Prompts { get; set; }
    public bool Logging { get; set; }
    public bool Completions { get; set; }
}

/// <summary>Top-level configuration for the MCP handler.</summary>
public class McpServerOptions
{
    public McpServerInfo ServerInfo { get; set; } = new McpServerInfo();
    public string ProtocolVersion { get; set; } = "2025-11-25";
    public McpCapabilities Capabilities { get; set; } = new McpCapabilities();
    public string Instructions { get; set; }
}

// ── Error Handling ───────────────────────────────────────────────────────────

/// <summary>Standard JSON-RPC 2.0 error codes used by MCP.</summary>
public enum McpErrorCode
{
    RequestTimeout = -32000,
    ParseError = -32700,
    InvalidRequest = -32600,
    MethodNotFound = -32601,
    InvalidParams = -32602,
    InternalError = -32603
}

/// <summary>
/// Throw from tool methods to surface a structured MCP error.
/// Mirrors ModelContextProtocol.McpException from the official SDK.
/// </summary>
public class McpException : Exception
{
    public McpErrorCode Code { get; }
    public McpException(McpErrorCode code, string message) : base(message) => Code = code;
}

// ── Schema Builder (Fluent API) ──────────────────────────────────────────────

/// <summary>Fluent builder for JSON Schema objects used in tool inputSchema.</summary>
public class McpSchemaBuilder
{
    private readonly JObject _properties = new JObject();
    private readonly JArray _required = new JArray();

    public McpSchemaBuilder String(string name, string description, bool required = false, string format = null, string[] enumValues = null)
    {
        var prop = new JObject { ["type"] = "string", ["description"] = description };
        if (format != null) prop["format"] = format;
        if (enumValues != null) prop["enum"] = new JArray(enumValues);
        _properties[name] = prop;
        if (required) _required.Add(name);
        return this;
    }

    public McpSchemaBuilder Integer(string name, string description, bool required = false, int? defaultValue = null)
    {
        var prop = new JObject { ["type"] = "integer", ["description"] = description };
        if (defaultValue.HasValue) prop["default"] = defaultValue.Value;
        _properties[name] = prop;
        if (required) _required.Add(name);
        return this;
    }

    public McpSchemaBuilder Number(string name, string description, bool required = false)
    {
        _properties[name] = new JObject { ["type"] = "number", ["description"] = description };
        if (required) _required.Add(name);
        return this;
    }

    public McpSchemaBuilder Boolean(string name, string description, bool required = false)
    {
        _properties[name] = new JObject { ["type"] = "boolean", ["description"] = description };
        if (required) _required.Add(name);
        return this;
    }

    public McpSchemaBuilder Array(string name, string description, JObject itemSchema, bool required = false)
    {
        _properties[name] = new JObject
        {
            ["type"] = "array",
            ["description"] = description,
            ["items"] = itemSchema
        };
        if (required) _required.Add(name);
        return this;
    }

    public McpSchemaBuilder Object(string name, string description, Action<McpSchemaBuilder> nestedConfig, bool required = false)
    {
        var nested = new McpSchemaBuilder();
        nestedConfig?.Invoke(nested);
        var obj = nested.Build();
        obj["description"] = description;
        _properties[name] = obj;
        if (required) _required.Add(name);
        return this;
    }

    public JObject Build()
    {
        var schema = new JObject
        {
            ["type"] = "object",
            ["properties"] = _properties
        };
        if (_required.Count > 0) schema["required"] = _required;
        return schema;
    }
}

// ── Internal Tool Registration ───────────────────────────────────────────────

internal class McpToolDefinition
{
    public string Name { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
    public JObject InputSchema { get; set; }
    public JObject OutputSchema { get; set; }
    public JObject Annotations { get; set; }
    public Func<JObject, CancellationToken, Task<object>> Handler { get; set; }
}

// ── Internal Resource Registration ───────────────────────────────────────────

internal class McpResourceDefinition
{
    public string Uri { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public string MimeType { get; set; }
    public JObject Annotations { get; set; }
    public Func<CancellationToken, Task<JArray>> Handler { get; set; }
}

internal class McpResourceTemplateDefinition
{
    public string UriTemplate { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
    public string MimeType { get; set; }
    public JObject Annotations { get; set; }
    public Func<string, CancellationToken, Task<JArray>> Handler { get; set; }
}

// ── Internal Prompt Registration ─────────────────────────────────────────────

/// <summary>Describes a single prompt argument.</summary>
public class McpPromptArgument
{
    public string Name { get; set; }
    public string Description { get; set; }
    public bool Required { get; set; }
}

internal class McpPromptDefinition
{
    public string Name { get; set; }
    public string Description { get; set; }
    public List<McpPromptArgument> Arguments { get; set; } = new List<McpPromptArgument>();
    public Func<JObject, CancellationToken, Task<JArray>> Handler { get; set; }
}

// ── McpRequestHandler ────────────────────────────────────────────────────────
//
//    The core bridge class. Stateless, no DI, no ASP.NET Core.
//    Takes a JSON-RPC string in → returns a JSON-RPC string out.
//    This is the class that does not exist in the official SDK today.
//

/// <summary>
/// Stateless MCP request handler that bridges the official SDK's patterns
/// to Power Platform's ScriptBase.ExecuteAsync() model.
/// 
/// Handles all JSON-RPC 2.0 routing, protocol negotiation, tool discovery,
/// parameter binding, and response formatting internally.
/// </summary>
public class McpRequestHandler
{
    private readonly McpServerOptions _options;
    private readonly Dictionary<string, McpToolDefinition> _tools;
    private readonly Dictionary<string, McpResourceDefinition> _resources;
    private readonly List<McpResourceTemplateDefinition> _resourceTemplates;
    private readonly Dictionary<string, McpPromptDefinition> _prompts;

    /// <summary>
    /// Optional logging callback. Wire this up to Application Insights,
    /// Context.Logger, or any other telemetry sink.
    /// </summary>
    public Action<string, object> OnLog { get; set; }

    public McpRequestHandler(McpServerOptions options)
    {
        _options = options ?? throw new ArgumentNullException(nameof(options));
        _tools = new Dictionary<string, McpToolDefinition>(StringComparer.OrdinalIgnoreCase);
        _resources = new Dictionary<string, McpResourceDefinition>(StringComparer.OrdinalIgnoreCase);
        _resourceTemplates = new List<McpResourceTemplateDefinition>();
        _prompts = new Dictionary<string, McpPromptDefinition>(StringComparer.OrdinalIgnoreCase);
    }

    // ── Tool Registration ────────────────────────────────────────────────

    /// <summary>
    /// Register a tool using the fluent API.
    /// Define the schema with McpSchemaBuilder, provide a handler, and optionally set annotations.
    /// </summary>
    public McpRequestHandler AddTool(
        string name,
        string description,
        Action<McpSchemaBuilder> schemaConfig,
        Func<JObject, CancellationToken, Task<JObject>> handler,
        Action<JObject> annotationsConfig = null,
        string title = null,
        Action<McpSchemaBuilder> outputSchemaConfig = null)
    {
        var builder = new McpSchemaBuilder();
        schemaConfig?.Invoke(builder);

        JObject annotations = null;
        if (annotationsConfig != null)
        {
            annotations = new JObject();
            annotationsConfig(annotations);
        }

        JObject outputSchema = null;
        if (outputSchemaConfig != null)
        {
            var outBuilder = new McpSchemaBuilder();
            outputSchemaConfig(outBuilder);
            outputSchema = outBuilder.Build();
        }

        _tools[name] = new McpToolDefinition
        {
            Name = name,
            Title = title,
            Description = description,
            InputSchema = builder.Build(),
            OutputSchema = outputSchema,
            Annotations = annotations,
            Handler = async (args, ct) => await handler(args, ct).ConfigureAwait(false)
        };

        return this;
    }

    // ── Resource Registration ─────────────────────────────────────────────

    /// <summary>
    /// Register a static resource. The handler returns the resource contents
    /// as a JArray of {uri, text, mimeType} or {uri, blob, mimeType} objects.
    /// </summary>
    public McpRequestHandler AddResource(
        string uri,
        string name,
        string description,
        Func<CancellationToken, Task<JArray>> handler,
        string mimeType = "application/json",
        Action<JObject> annotationsConfig = null)
    {
        JObject annotations = null;
        if (annotationsConfig != null)
        {
            annotations = new JObject();
            annotationsConfig(annotations);
        }

        _resources[uri] = new McpResourceDefinition
        {
            Uri = uri,
            Name = name,
            Description = description,
            MimeType = mimeType,
            Annotations = annotations,
            Handler = handler
        };

        return this;
    }

    /// <summary>
    /// Register a resource template. The handler receives the resolved URI
    /// and returns the resource contents as a JArray.
    /// </summary>
    public McpRequestHandler AddResourceTemplate(
        string uriTemplate,
        string name,
        string description,
        Func<string, CancellationToken, Task<JArray>> handler,
        string mimeType = "application/json",
        Action<JObject> annotationsConfig = null)
    {
        JObject annotations = null;
        if (annotationsConfig != null)
        {
            annotations = new JObject();
            annotationsConfig(annotations);
        }

        _resourceTemplates.Add(new McpResourceTemplateDefinition
        {
            UriTemplate = uriTemplate,
            Name = name,
            Description = description,
            MimeType = mimeType,
            Annotations = annotations,
            Handler = handler
        });

        return this;
    }

    // ── Prompt Registration ──────────────────────────────────────────────

    /// <summary>
    /// Register a prompt. The handler receives the argument values as a JObject
    /// and returns a JArray of message objects ({role, content: {type, text}}).
    /// </summary>
    public McpRequestHandler AddPrompt(
        string name,
        string description,
        List<McpPromptArgument> arguments,
        Func<JObject, CancellationToken, Task<JArray>> handler)
    {
        _prompts[name] = new McpPromptDefinition
        {
            Name = name,
            Description = description,
            Arguments = arguments ?? new List<McpPromptArgument>(),
            Handler = handler
        };

        return this;
    }

    // ── Main Handler ─────────────────────────────────────────────────────

    /// <summary>
    /// Process a raw JSON-RPC 2.0 request string and return a JSON-RPC response string.
    /// This is the single method that bridges the gap.
    /// </summary>
    public async Task<string> HandleAsync(string body, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(body))
            return SerializeError(null, McpErrorCode.InvalidRequest, "Empty request body");

        JObject request;
        try
        {
            request = JObject.Parse(body);
        }
        catch (JsonException)
        {
            return SerializeError(null, McpErrorCode.ParseError, "Invalid JSON");
        }

        var method = request.Value<string>("method") ?? string.Empty;
        var id = request["id"];

        Log("McpRequestReceived", new { Method = method, HasId = id != null });

        try
        {
            switch (method)
            {
                // Core initialization
                case "initialize":
                    return HandleInitialize(id, request);

                // Notifications — Copilot Studio requires valid JSON-RPC for ALL requests
                case "initialized":
                case "notifications/initialized":
                case "notifications/cancelled":
                case "notifications/roots/list_changed":
                    return SerializeSuccess(id, new JObject());

                // Health check
                case "ping":
                    return SerializeSuccess(id, new JObject());

                // Tools
                case "tools/list":
                    return HandleToolsList(id);

                case "tools/call":
                    return await HandleToolsCallAsync(id, request, cancellationToken).ConfigureAwait(false);

                // Resources
                case "resources/list":
                    return HandleResourcesList(id);

                case "resources/templates/list":
                    return HandleResourceTemplatesList(id);

                case "resources/read":
                    return await HandleResourcesReadAsync(id, request, cancellationToken).ConfigureAwait(false);

                case "resources/subscribe":
                case "resources/unsubscribe":
                    return SerializeSuccess(id, new JObject());

                // Prompts
                case "prompts/list":
                    return HandlePromptsList(id);

                case "prompts/get":
                    return await HandlePromptsGetAsync(id, request, cancellationToken).ConfigureAwait(false);

                // Completions
                case "completion/complete":
                    return SerializeSuccess(id, new JObject
                    {
                        ["completion"] = new JObject
                        {
                            ["values"] = new JArray(),
                            ["total"] = 0,
                            ["hasMore"] = false
                        }
                    });

                // Logging level
                case "logging/setLevel":
                    return SerializeSuccess(id, new JObject());

                default:
                    Log("McpMethodNotFound", new { Method = method });
                    return SerializeError(id, McpErrorCode.MethodNotFound, "Method not found", method);
            }
        }
        catch (McpException ex)
        {
            Log("McpError", new { Method = method, Code = (int)ex.Code, Message = ex.Message });
            return SerializeError(id, ex.Code, ex.Message);
        }
        catch (Exception ex)
        {
            Log("McpError", new { Method = method, Error = ex.Message });
            return SerializeError(id, McpErrorCode.InternalError, ex.Message);
        }
    }

    // ── Protocol Handlers ────────────────────────────────────────────────

    private string HandleInitialize(JToken id, JObject request)
    {
        var clientProtocolVersion = request["params"]?["protocolVersion"]?.ToString()
            ?? _options.ProtocolVersion;

        var capabilities = new JObject();
        if (_options.Capabilities.Tools)
            capabilities["tools"] = new JObject { ["listChanged"] = false };
        if (_options.Capabilities.Resources)
            capabilities["resources"] = new JObject { ["subscribe"] = false, ["listChanged"] = false };
        if (_options.Capabilities.Prompts)
            capabilities["prompts"] = new JObject { ["listChanged"] = false };
        if (_options.Capabilities.Logging)
            capabilities["logging"] = new JObject();
        if (_options.Capabilities.Completions)
            capabilities["completions"] = new JObject();

        var serverInfo = new JObject
        {
            ["name"] = _options.ServerInfo.Name,
            ["version"] = _options.ServerInfo.Version
        };
        if (!string.IsNullOrWhiteSpace(_options.ServerInfo.Title))
            serverInfo["title"] = _options.ServerInfo.Title;
        if (!string.IsNullOrWhiteSpace(_options.ServerInfo.Description))
            serverInfo["description"] = _options.ServerInfo.Description;

        var result = new JObject
        {
            ["protocolVersion"] = clientProtocolVersion,
            ["capabilities"] = capabilities,
            ["serverInfo"] = serverInfo
        };

        if (!string.IsNullOrWhiteSpace(_options.Instructions))
            result["instructions"] = _options.Instructions;

        Log("McpInitialized", new
        {
            Server = _options.ServerInfo.Name,
            Version = _options.ServerInfo.Version,
            ProtocolVersion = clientProtocolVersion
        });

        return SerializeSuccess(id, result);
    }

    private string HandleToolsList(JToken id)
    {
        var toolsArray = new JArray();
        foreach (var tool in _tools.Values)
        {
            var toolObj = new JObject
            {
                ["name"] = tool.Name,
                ["description"] = tool.Description,
                ["inputSchema"] = tool.InputSchema
            };
            if (!string.IsNullOrWhiteSpace(tool.Title))
                toolObj["title"] = tool.Title;
            if (tool.OutputSchema != null)
                toolObj["outputSchema"] = tool.OutputSchema;
            if (tool.Annotations != null && tool.Annotations.Count > 0)
                toolObj["annotations"] = tool.Annotations;
            toolsArray.Add(toolObj);
        }

        Log("McpToolsListed", new { Count = _tools.Count });
        return SerializeSuccess(id, new JObject { ["tools"] = toolsArray });
    }

    private string HandleResourcesList(JToken id)
    {
        var resourcesArray = new JArray();
        foreach (var res in _resources.Values)
        {
            var obj = new JObject
            {
                ["uri"] = res.Uri,
                ["name"] = res.Name
            };
            if (!string.IsNullOrWhiteSpace(res.Description))
                obj["description"] = res.Description;
            if (!string.IsNullOrWhiteSpace(res.MimeType))
                obj["mimeType"] = res.MimeType;
            if (res.Annotations != null && res.Annotations.Count > 0)
                obj["annotations"] = res.Annotations;
            resourcesArray.Add(obj);
        }

        Log("McpResourcesListed", new { Count = _resources.Count });
        return SerializeSuccess(id, new JObject { ["resources"] = resourcesArray });
    }

    private string HandleResourceTemplatesList(JToken id)
    {
        var templatesArray = new JArray();
        foreach (var tmpl in _resourceTemplates)
        {
            var obj = new JObject
            {
                ["uriTemplate"] = tmpl.UriTemplate,
                ["name"] = tmpl.Name
            };
            if (!string.IsNullOrWhiteSpace(tmpl.Description))
                obj["description"] = tmpl.Description;
            if (!string.IsNullOrWhiteSpace(tmpl.MimeType))
                obj["mimeType"] = tmpl.MimeType;
            if (tmpl.Annotations != null && tmpl.Annotations.Count > 0)
                obj["annotations"] = tmpl.Annotations;
            templatesArray.Add(obj);
        }

        Log("McpResourceTemplatesListed", new { Count = _resourceTemplates.Count });
        return SerializeSuccess(id, new JObject { ["resourceTemplates"] = templatesArray });
    }

    private async Task<string> HandleResourcesReadAsync(JToken id, JObject request, CancellationToken ct)
    {
        var paramsObj = request["params"] as JObject;
        var uri = paramsObj?.Value<string>("uri");

        if (string.IsNullOrWhiteSpace(uri))
            return SerializeError(id, McpErrorCode.InvalidParams, "Resource URI is required");

        // 1. Try exact match on registered static resources
        if (_resources.TryGetValue(uri, out var resource))
        {
            Log("McpResourceReadStarted", new { Uri = uri });
            try
            {
                var contents = await resource.Handler(ct).ConfigureAwait(false);
                Log("McpResourceReadCompleted", new { Uri = uri });
                return SerializeSuccess(id, new JObject { ["contents"] = contents });
            }
            catch (Exception ex)
            {
                Log("McpResourceReadError", new { Uri = uri, Error = ex.Message });
                return SerializeError(id, McpErrorCode.InternalError, ex.Message);
            }
        }

        // 2. Try matching against registered resource templates
        foreach (var tmpl in _resourceTemplates)
        {
            if (MatchesUriTemplate(tmpl.UriTemplate, uri))
            {
                Log("McpResourceReadStarted", new { Uri = uri, Template = tmpl.UriTemplate });
                try
                {
                    var contents = await tmpl.Handler(uri, ct).ConfigureAwait(false);
                    Log("McpResourceReadCompleted", new { Uri = uri });
                    return SerializeSuccess(id, new JObject { ["contents"] = contents });
                }
                catch (Exception ex)
                {
                    Log("McpResourceReadError", new { Uri = uri, Error = ex.Message });
                    return SerializeError(id, McpErrorCode.InternalError, ex.Message);
                }
            }
        }

        return SerializeError(id, McpErrorCode.InvalidParams, $"Resource not found: {uri}");
    }

    /// <summary>
    /// Simple URI template matcher. Checks if a concrete URI matches a template
    /// with {param} placeholders (e.g., "data://records/{id}" matches "data://records/123").
    /// </summary>
    private static bool MatchesUriTemplate(string template, string uri)
    {
        // Split both on '/' and compare segments
        var templateParts = template.Split('/');
        var uriParts = uri.Split('/');

        if (templateParts.Length != uriParts.Length) return false;

        for (int i = 0; i < templateParts.Length; i++)
        {
            var seg = templateParts[i];
            if (seg.StartsWith("{") && seg.EndsWith("}")) continue; // wildcard
            if (!string.Equals(seg, uriParts[i], StringComparison.OrdinalIgnoreCase)) return false;
        }
        return true;
    }

    /// <summary>
    /// Extract named parameters from a URI given a template pattern.
    /// E.g., template "data://records/{id}" with uri "data://records/123" returns { "id": "123" }.
    /// </summary>
    public static Dictionary<string, string> ExtractUriParameters(string template, string uri)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var templateParts = template.Split('/');
        var uriParts = uri.Split('/');

        if (templateParts.Length != uriParts.Length) return result;

        for (int i = 0; i < templateParts.Length; i++)
        {
            var seg = templateParts[i];
            if (seg.StartsWith("{") && seg.EndsWith("}"))
            {
                var paramName = seg.Substring(1, seg.Length - 2);
                result[paramName] = uriParts[i];
            }
        }
        return result;
    }

    private string HandlePromptsList(JToken id)
    {
        var promptsArray = new JArray();
        foreach (var prompt in _prompts.Values)
        {
            var obj = new JObject
            {
                ["name"] = prompt.Name
            };
            if (!string.IsNullOrWhiteSpace(prompt.Description))
                obj["description"] = prompt.Description;

            if (prompt.Arguments.Count > 0)
            {
                var argsArray = new JArray();
                foreach (var arg in prompt.Arguments)
                {
                    var argObj = new JObject { ["name"] = arg.Name };
                    if (!string.IsNullOrWhiteSpace(arg.Description))
                        argObj["description"] = arg.Description;
                    if (arg.Required)
                        argObj["required"] = true;
                    argsArray.Add(argObj);
                }
                obj["arguments"] = argsArray;
            }

            promptsArray.Add(obj);
        }

        Log("McpPromptsListed", new { Count = _prompts.Count });
        return SerializeSuccess(id, new JObject { ["prompts"] = promptsArray });
    }

    private async Task<string> HandlePromptsGetAsync(JToken id, JObject request, CancellationToken ct)
    {
        var paramsObj = request["params"] as JObject;
        var promptName = paramsObj?.Value<string>("name");
        var arguments = paramsObj?["arguments"] as JObject ?? new JObject();

        if (string.IsNullOrWhiteSpace(promptName))
            return SerializeError(id, McpErrorCode.InvalidParams, "Prompt name is required");

        if (!_prompts.TryGetValue(promptName, out var prompt))
            return SerializeError(id, McpErrorCode.InvalidParams, $"Prompt not found: {promptName}");

        Log("McpPromptGetStarted", new { Prompt = promptName });

        try
        {
            var messages = await prompt.Handler(arguments, ct).ConfigureAwait(false);
            Log("McpPromptGetCompleted", new { Prompt = promptName, MessageCount = messages.Count });

            var result = new JObject { ["messages"] = messages };
            if (!string.IsNullOrWhiteSpace(prompt.Description))
                result["description"] = prompt.Description;

            return SerializeSuccess(id, result);
        }
        catch (Exception ex)
        {
            Log("McpPromptGetError", new { Prompt = promptName, Error = ex.Message });
            return SerializeError(id, McpErrorCode.InternalError, ex.Message);
        }
    }

    private async Task<string> HandleToolsCallAsync(JToken id, JObject request, CancellationToken ct)
    {
        var paramsObj = request["params"] as JObject;
        var toolName = paramsObj?.Value<string>("name");
        var arguments = paramsObj?["arguments"] as JObject ?? new JObject();

        if (string.IsNullOrWhiteSpace(toolName))
            return SerializeError(id, McpErrorCode.InvalidParams, "Tool name is required");

        if (!_tools.TryGetValue(toolName, out var tool))
            return SerializeError(id, McpErrorCode.InvalidParams, $"Unknown tool: {toolName}");

        Log("McpToolCallStarted", new { Tool = toolName });

        try
        {
            var result = await tool.Handler(arguments, ct).ConfigureAwait(false);

            JObject callResult;

            // Support pre-formatted MCP tool results with rich content types
            // (image, audio, resource, or mixed content arrays).
            // If the handler returns { "content": [ { "type": "..." } ], ... },
            // pass it through directly instead of wrapping in text.
            if (result is JObject jobj && jobj["content"] is JArray contentArray
                && contentArray.Count > 0 && contentArray[0]?["type"] != null)
            {
                callResult = new JObject
                {
                    ["content"] = contentArray,
                    ["isError"] = jobj.Value<bool?>("isError") ?? false
                };
                if (jobj["structuredContent"] is JObject structured)
                    callResult["structuredContent"] = structured;
            }
            else
            {
                string text;
                if (result is JObject plainObj)
                    text = plainObj.ToString(Newtonsoft.Json.Formatting.Indented);
                else if (result is string s)
                    text = s;
                else if (result == null)
                    text = "{}";
                else
                    text = JsonConvert.SerializeObject(result, Newtonsoft.Json.Formatting.Indented);

                callResult = new JObject
                {
                    ["content"] = new JArray { new JObject { ["type"] = "text", ["text"] = text } },
                    ["isError"] = false
                };
            }

            Log("McpToolCallCompleted", new { Tool = toolName, IsError = callResult.Value<bool>("isError") });
            return SerializeSuccess(id, callResult);
        }
        catch (ArgumentException ex)
        {
            return SerializeSuccess(id, new JObject
            {
                ["content"] = new JArray
                {
                    new JObject { ["type"] = "text", ["text"] = $"Invalid arguments: {ex.Message}" }
                },
                ["isError"] = true
            });
        }
        catch (McpException ex)
        {
            return SerializeSuccess(id, new JObject
            {
                ["content"] = new JArray
                {
                    new JObject { ["type"] = "text", ["text"] = $"Tool error: {ex.Message}" }
                },
                ["isError"] = true
            });
        }
        catch (Exception ex)
        {
            Log("McpToolCallError", new { Tool = toolName, Error = ex.Message });

            return SerializeSuccess(id, new JObject
            {
                ["content"] = new JArray
                {
                    new JObject { ["type"] = "text", ["text"] = $"Tool execution failed: {ex.Message}" }
                },
                ["isError"] = true
            });
        }
    }

    // ── Content Helpers ────────────────────────────────────────────────
    //
    //    Use these to build rich tool results with image, audio, or resource
    //    content. Return McpRequestHandler.ToolResult(...) from your handler
    //    to bypass automatic text wrapping.
    //

    /// <summary>Create a text content item.</summary>
    public static JObject TextContent(string text) =>
        new JObject { ["type"] = "text", ["text"] = text };

    /// <summary>Create an image content item (base64-encoded).</summary>
    public static JObject ImageContent(string base64Data, string mimeType) =>
        new JObject { ["type"] = "image", ["data"] = base64Data, ["mimeType"] = mimeType };

    /// <summary>Create an audio content item (base64-encoded).</summary>
    public static JObject AudioContent(string base64Data, string mimeType) =>
        new JObject { ["type"] = "audio", ["data"] = base64Data, ["mimeType"] = mimeType };

    /// <summary>Create an embedded resource content item.</summary>
    public static JObject ResourceContent(string uri, string text, string mimeType = "text/plain") =>
        new JObject
        {
            ["type"] = "resource",
            ["resource"] = new JObject { ["uri"] = uri, ["text"] = text, ["mimeType"] = mimeType }
        };

    /// <summary>
    /// Build a pre-formatted tool result with mixed content types.
    /// Return this from a tool handler to bypass automatic text wrapping.
    /// </summary>
    public static JObject ToolResult(JArray content, JObject structuredContent = null, bool isError = false)
    {
        var result = new JObject { ["content"] = content, ["isError"] = isError };
        if (structuredContent != null) result["structuredContent"] = structuredContent;
        return result;
    }

    // ── JSON-RPC Serialization ───────────────────────────────────────────

    private string SerializeSuccess(JToken id, JObject result)
    {
        return new JObject
        {
            ["jsonrpc"] = "2.0",
            ["id"] = id,
            ["result"] = result
        }.ToString(Newtonsoft.Json.Formatting.None);
    }

    private string SerializeError(JToken id, McpErrorCode code, string message, string data = null)
    {
        return SerializeError(id, (int)code, message, data);
    }

    private string SerializeError(JToken id, int code, string message, string data = null)
    {
        var error = new JObject
        {
            ["code"] = code,
            ["message"] = message
        };
        if (!string.IsNullOrWhiteSpace(data))
            error["data"] = data;

        return new JObject
        {
            ["jsonrpc"] = "2.0",
            ["id"] = id,
            ["error"] = error
        }.ToString(Newtonsoft.Json.Formatting.None);
    }

    private void Log(string eventName, object data)
    {
        OnLog?.Invoke(eventName, data);
    }
}

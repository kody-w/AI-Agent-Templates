---
name: insuranceehrbedding
description: Runs the automated payer eligibility check (flagging coverage gaps and pre-authorisation requirements to admissions staff) and tracks the EHR intake write-back and bed/care-area allocation with receiving-team notification. Records live in Microsoft Dataverse. Identify patients by NATURAL reference: a name or PT- reference; 'list' shows every eligibility and bed status. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# InsuranceEhrBedding skill

## When to use

- Show Insurance Ehr Bedding for patientref PT-4474.
- Are there any coverage gaps or pre-auth flags today?
- Which beds have been allocated?

## Rules (single source of truth)

- The bundled `insurance_ehr_bedding_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_insuranceehrbedding`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs or deep links. Refer to records by their plain reference (e.g. PT-4474) only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `patientRef` — Patient name or PT- reference, e.g. 'Marcus Reid' or PT-4474. Pass the word: list to see every eligibility and bed status - never ask the user for an id.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_insuranceehrbedding` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 insurance_ehr_bedding_agent.py --data-json '{"_CANON": <items from list_insuranceehrbedding>}' --kwargs-json '{"patientRef": "Marcus Reid' or PT-4474. Pas"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `PT-4471`.

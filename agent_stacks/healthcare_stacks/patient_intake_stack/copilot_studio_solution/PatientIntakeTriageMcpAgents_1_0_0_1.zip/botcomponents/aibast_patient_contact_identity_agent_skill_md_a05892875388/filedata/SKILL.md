---
name: patientcontactidentity
description: Handles first contact on any channel (web portal, mobile app, phone, walk-in), initiates the structured intake conversation, and verifies the patient's identity against the Patient Administration System — matching their existing medical record or flagging a new patient. Intake records live in Microsoft Dataverse. Identify patients by NATURAL reference: a name like 'Grace Holt' or a PT- reference; never ask for internal identifiers. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# PatientContactIdentity skill

## When to use

- Show Patient Contact Identity for patientref PT-4471.
- Who has arrived for intake today?
- Register a new patient contact: Jordan Blake via web portal

## Rules (single source of truth)

- The bundled `patient_contact_identity_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_patientcontactidentity`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference (e.g. PT-4471) only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `patientRef` — Patient name or PT- reference, e.g. 'Grace Holt' or PT-4471. Pass the word: list to see today's intake queue - never ask the user for an id.
- `patientName` — Name for a NEW patient contact (optional).
- `channel` — Channel for a NEW contact: web portal, mobile app, phone, or walk-in (optional).

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_patientcontactidentity` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 patient_contact_identity_agent.py --data-json '{"_CANON": <items from list_patientcontactidentity>}' --kwargs-json '{"patientRef": "Grace Holt' or PT-4471. Pass"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `PT-4471`.

---
name: symptomtriagescoring
description: Captures the guided symptom and history assessment (presenting symptoms, duration, severity, history, allergies, medications) and applies validated Manchester Triage System discriminators to produce a priority category (RED / ORANGE / YELLOW / GREEN) with the clinical rationale. Assessments live in Microsoft Dataverse. Identify patients by NATURAL reference: a name or PT- reference; 'list' ranks today's queue by priority. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# SymptomTriageScoring skill

## When to use

- Show Symptom Triage Scoring for patientref PT-4474.
- Run the triage assessment for Grace Holt
- Which patients are highest priority right now?

## Rules (single source of truth)

- The bundled `symptom_triage_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_symptomtriagescoring`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs or deep links. Refer to records by their plain reference (e.g. PT-4471) only. This is synthetic demo data - never present it as real clinical advice. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `patientRef` — Patient name or PT- reference, e.g. 'Marcus Reid' or PT-4474. Pass the word: list to rank today's assessments by priority - never ask the user for an id.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_symptomtriagescoring` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 symptom_triage_agent.py --data-json '{"_CANON": <items from list_symptomtriagescoring>}' --kwargs-json '{"patientRef": "Marcus Reid' or PT-4474. Pas"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `PT-4471`.

"""Insurance & Eligibility Verification + EHR Record Update & Bed
Allocation — steps 7-8 of the Intelligent Patient Intake & Triage process
flow.

Step 7 — Insurance & Eligibility Verification: An automated eligibility
check runs against the payer system, flagging coverage gaps or
pre-authorisation requirements to admissions staff. (Payer / Insurance
System)

Step 8 — EHR Record Update & Bed Allocation: Completed intake data is
written to the EHR System; the patient is assigned to the appropriate care
area and the receiving clinical team notified. (EHR System, Power Automate)

Data home: Microsoft Dataverse.
"""
try:
    from agents.basic_agent import BasicAgent
except ImportError:
    class BasicAgent:
        def __init__(self, name, metadata):
            self.name, self.metadata = name, metadata

_CANON = []  # data arrives at runtime from the MCP server (--data-json); the connector is the single source of truth


class InsuranceEhrBedding(BasicAgent):
    CAPIR = {"binding": {"system": "Microsoft Dataverse", "table": "accounts"}}
    TRIGGERS = [
        "Show Insurance Ehr Bedding for patientref PT-4474.",
        "Are there any coverage gaps or pre-auth flags today?",
        "Which beds have been allocated?",
    ]
    RESPONSE = ("Present records as plain text fields. NEVER invent, guess, "
                "or fabricate URLs or deep links. Refer to records by their "
                "plain reference (e.g. PT-4474) only. Keep answers under "
                "~120 words, professional markdown, no emojis.")
    SYNTHETIC_DATA = list(_CANON)

    def __init__(self):
        self.name = "InsuranceEhrBedding"
        self.metadata = {
            "name": self.name,
            "description": (
                "Runs the automated payer eligibility check (flagging "
                "coverage gaps and pre-authorisation requirements to "
                "admissions staff) and tracks the EHR intake write-back "
                "and bed/care-area allocation with receiving-team "
                "notification. Records live in Microsoft Dataverse. "
                "Identify patients by NATURAL reference: a name or PT- "
                "reference; 'list' shows every eligibility and bed status."),
            "parameters": {
                "type": "object",
                "properties": {
                    "patientRef": {
                        "type": "string",
                        "description": ("Patient name or PT- reference, "
                                        "e.g. 'Marcus Reid' or PT-4474. "
                                        "Pass the word: list to see every "
                                        "eligibility and bed status - "
                                        "never ask the user for an id.")},
                },
                "required": [],
            },
        }
        super().__init__(self.name, self.metadata)

    def perform(self, **kwargs):
        ref = str(kwargs.get("patientRef") or "").strip()
        low = ref.lower()
        if not ref or low == "list":
            lines = ["## Eligibility, EHR & bed status"]
            for i, p in enumerate(_CANON, 1):
                flag = (" ⚠" if "GAP" in p["eligibilityStatus"]
                        or "yes" in p["preAuthRequired"] else "")
                lines.append(f"{i}. **{p['patientRef']}** "
                             f"{p['patientName']} — "
                             f"{p['eligibilityStatus']}{flag} — "
                             f"{p['bedAllocation']}")
            lines.append("")
            lines.append("Open a patient for the full eligibility and EHR "
                         "detail.")
            return "\n".join(lines)
        hits = [p for p in _CANON if low == p["patientRef"].lower()
                or low in p["patientName"].lower()]
        if not hits:
            return (f"No record matches `{ref}`. Say 'list' for every "
                    "status.")
        p = hits[0]
        return "\n".join([
            f"## {p['patientRef']} — {p['patientName']}",
            f"- Payer: {p['payerName']}",
            f"- Eligibility: {p['eligibilityStatus']}",
            f"- Pre-authorisation: {p['preAuthRequired']}",
            f"- EHR: {p['ehrStatus']}",
            f"- Bed / care area: {p['bedAllocation']}",
        ])


if __name__ == "__main__":  # thin-skill entrypoint (generated)
    import argparse as _ap
    import json as _js
    import sys as _sys
    _p = _ap.ArgumentParser(description="Run the InsuranceEhrBedding capability on "
                                        "records fetched from the MCP server.")
    _p.add_argument("--data-json", default="{}",
                    help="JSON object mapping dataset names to record arrays "
                         "fetched from the MCP server, e.g. "
                         "'{\"_CANON\": <items from list_insuranceehrbedding>}'")
    _p.add_argument("--kwargs-json", default="{}",
                    help="JSON object of perform() keyword arguments.")
    _a = _p.parse_args()
    try:
        _data = _js.loads(_a.data_json)
        _kw = _js.loads(_a.kwargs_json)
    except Exception as _e:
        print("Invalid JSON argument: %s" % _e)
        _sys.exit(2)
    _g = globals()
    for _name, _rows in (_data or {}).items():
        if _name in _g and isinstance(_rows, (list, dict)):
            _g[_name] = _rows
        for _obj in list(_g.values()):
            if isinstance(_obj, type) and hasattr(_obj, _name):
                setattr(_obj, _name, _rows)
    def _have(_n):
        if _g.get(_n):
            return True
        return any(isinstance(_o, type) and getattr(_o, _n, None)
                   for _o in list(_g.values()))
    _missing = [n for n in ['_CANON'] if not _have(n)]
    if _missing:
        print("No data provided for: %s. Fetch records from the MCP server "
              "(list_insuranceehrbedding) first and pass them via --data-json."
              % ", ".join(_missing))
        _sys.exit(3)
    print(InsuranceEhrBedding().perform(**_kw))

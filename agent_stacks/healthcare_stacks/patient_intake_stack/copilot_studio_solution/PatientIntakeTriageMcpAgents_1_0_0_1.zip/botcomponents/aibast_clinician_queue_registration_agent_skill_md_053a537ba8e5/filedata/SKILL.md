---
name: clinicianqueueregistration
description: Tracks the clinician alerting and care-queue placement driven by each patient's triage category (RED to resus, ORANGE to majors, YELLOW to minors/majors, GREEN to ambulatory) and the pre-populated registration form's signature status. Queue and registration records live in Microsoft Dataverse. Identify patients by NATURAL reference: a name or PT- reference; 'list' shows every queue placement. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# ClinicianQueueRegistration skill

## When to use

- Show Clinician Queue Registration for patientref PT-4474.
- Which care queue is each patient in?
- Has Grace Holt signed her registration form?

## Rules (single source of truth)

- The bundled `clinician_queue_registration_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_clinicianqueueregistration`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs or deep links. Refer to records by their plain reference (e.g. PT-4474) only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `patientRef` — Patient name or PT- reference, e.g. 'Grace Holt' or PT-4471. Pass the word: list to see every care-queue placement - never ask the user for an id.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_clinicianqueueregistration` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 clinician_queue_registration_agent.py --data-json '{"_CANON": <items from list_clinicianqueueregistration>}' --kwargs-json '{"patientRef": "Grace Holt' or PT-4471. Pass"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `PT-4474`.

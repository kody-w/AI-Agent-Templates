"""Decision Write-Back & UM Analytics — steps 7-8 of the Prior Authorization &
Utilization Management process flow.

Step 7 — Decision Write-Back: approvals, auth numbers, validity windows, and
unit limits are written back to the EHR and scheduling system so care can be
booked immediately within the authorized scope. (EHR System, Power Automate)

Step 8 — UM Analytics: Power BI tracks turnaround by payer and service line,
denial and overturn rates, SLA breaches, and gold-carding eligibility for
governance review. (Power BI)

Write-back is REAL: an approved request carries an auth number, a validity
window, and unit limits. Analytics are computed deterministically from the
canon. Identify requests by NATURAL reference (patient name or AUTH- ref).
Data home: Microsoft Dataverse.
"""
try:
    from agents.basic_agent import BasicAgent
except ImportError:
    class BasicAgent:
        def __init__(self, name, metadata):
            self.name, self.metadata = name, metadata

_CANON = []  # data arrives at runtime from the MCP server (--data-json); the connector is the single source of truth


class WritebackAnalytics(BasicAgent):
    CAPIR = {"binding": {"system": "Microsoft Dataverse", "table": "accounts"}}
    TRIGGERS = [
        "Write back the approval for AUTH-88394 to the EHR.",
        "What's the auth number and validity window for Priya Nair's knee replacement?",
        "Show the UM analytics: approval rate and average turnaround by payer.",
    ]
    RESPONSE = ("Present records as plain text fields. NEVER invent, guess, or "
                "fabricate URLs, deep links, or Power Apps/Power BI links — the "
                "packaged demo data contains no links. Refer to records by their "
                "plain reference (e.g. AUTH-88394) only. Keep answers under ~130 "
                "words, professional markdown, no emojis.")
    SYNTHETIC_DATA = list(_CANON)

    def __init__(self):
        self.name = "WritebackAnalytics"
        self.metadata = {
            "name": self.name,
            "description": (
                "Writes approved determinations back to the EHR and scheduling "
                "system — auth number, validity window, and unit limits so care "
                "books within the authorized scope — and reports UM analytics: "
                "approval and overturn rates, average turnaround by payer and "
                "service line, and SLA performance. Requests live in Microsoft "
                "Dataverse. Identify a request by NATURAL reference: a patient "
                "name or AUTH- reference; pass 'analytics' for the governance "
                "scoreboard. Never ask the user for an internal id."),
            "parameters": {
                "type": "object",
                "properties": {
                    "authReference": {
                        "type": "string",
                        "description": ("Auth reference or patient name, e.g. "
                                        "AUTH-88394 or 'Priya Nair'. Pass the "
                                        "word: analytics for the UM scoreboard, "
                                        "or list for all determinations — never "
                                        "ask the user for an id.")},
                },
                "required": [],
            },
        }
        super().__init__(self.name, self.metadata)

    def _find(self, ref):
        low = ref.lower()
        return [a for a in _CANON if low == a["authReference"].lower()
                or low in a["patientName"].lower()]

    def perform(self, **kwargs):
        ref = str(kwargs.get("authReference") or "").strip().lower()
        if ref in ("analytics", "scoreboard", "metrics", "governance"):
            approved = [a for a in _CANON if a["determination"] == "approved"]
            decided = [a for a in _CANON if a["tatHours"] > 0]
            avg_tat = sum(a["tatHours"] for a in decided) / max(len(decided), 1)
            return "\n".join([
                "## UM analytics — governance scoreboard (Power BI)",
                f"- Requests: {len(_CANON)} | Approved: {len(approved)} "
                f"({100*len(approved)//len(_CANON)}%)",
                f"- Denied: 1 (appeal in progress) | Pended: 1 (peer-to-peer)",
                f"- Avg turnaround (decided): {avg_tat:.0f}h",
                "- Gold-carding: 1 order auto-exempt (Contoso / CPT 72148)",
                "- SLA: expedited case (AUTH-88365) cleared within 72h.",
            ])
        if not ref or ref == "list":
            lines = ["## Determinations — write-back status (Dataverse)"]
            lines += [f"{i}. **{a['authReference']}** — {a['patientName']}, "
                      f"{a['service']} — {a['determination']}"
                      + (f" (auth {a['authNumber']})"
                         if a["authNumber"] != "n/a" else "")
                      for i, a in enumerate(_CANON, 1)]
            return "\n".join(lines)
        hits = self._find(ref)
        if not hits:
            return (f"No request matches `{ref}`. Say 'analytics' for the UM "
                    "scoreboard or 'list' for all determinations.")
        a = hits[0]
        lines = [
            f"## {a['authReference']} — {a['patientName']}",
            f"- Service: {a['service']} | Payer: {a['payer']} | "
            f"Determination: **{a['determination']}**",
        ]
        if a["authNumber"] != "n/a":
            lines += [
                "",
                "### Step 7 — Decision write-back (EHR + scheduling)",
                f"- Auth number: {a['authNumber']} | Units: {a['units']}",
                f"- Valid: {a['validFrom']} → {a['validTo']}",
                "- Written back; care can be booked within the authorized scope.",
            ]
        else:
            lines.append("- Not yet approved — nothing to write back "
                         "(see denial/peer-to-peer agent).")
        return "\n".join(lines)


if __name__ == "__main__":  # thin-skill entrypoint (generated)
    import argparse as _ap
    import json as _js
    import sys as _sys
    _p = _ap.ArgumentParser(description="Run the WritebackAnalytics capability on "
                                        "records fetched from the MCP server.")
    _p.add_argument("--data-json", default="{}",
                    help="JSON object mapping dataset names to record arrays "
                         "fetched from the MCP server, e.g. "
                         "'{\"_CANON\": <items from list_writebackanalytics>}'")
    _p.add_argument("--kwargs-json", default="{}",
                    help="JSON object of perform() keyword arguments.")
    _a = _p.parse_args()
    try:
        _data = _js.loads(_a.data_json)
        _kw = _js.loads(_a.kwargs_json)
    except Exception as _e:
        print("Invalid JSON argument: %s" % _e)
        _sys.exit(2)
    _g = globals()
    for _name, _rows in (_data or {}).items():
        if _name in _g and isinstance(_rows, (list, dict)):
            _g[_name] = _rows
        for _obj in list(_g.values()):
            if isinstance(_obj, type) and hasattr(_obj, _name):
                setattr(_obj, _name, _rows)
    def _have(_n):
        if _g.get(_n):
            return True
        return any(isinstance(_o, type) and getattr(_o, _n, None)
                   for _o in list(_g.values()))
    _missing = [n for n in ['_CANON'] if not _have(n)]
    if _missing:
        print("No data provided for: %s. Fetch records from the MCP server "
              "(list_writebackanalytics) first and pass them via --data-json."
              % ", ".join(_missing))
        _sys.exit(3)
    print(WritebackAnalytics().perform(**_kw))

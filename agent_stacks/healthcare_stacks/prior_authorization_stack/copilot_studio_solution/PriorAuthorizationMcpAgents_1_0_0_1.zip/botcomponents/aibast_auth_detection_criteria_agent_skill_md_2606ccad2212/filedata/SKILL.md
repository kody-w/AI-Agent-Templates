---
name: authdetectioncriteria
description: Detects whether a placed order requires prior authorization by checking the CPT/HCPCS code and plan against the payer rules engine (honouring gold-carding exemptions), then assembles the clinical-evidence packet from the EHR and maps it against the payer's MCG/InterQual medical-necessity criteria. Requests live in Microsoft Dataverse. Identify a request by NATURAL reference: a patient name, CPT code, or AUTH- reference; never ask the user for an internal id. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# AuthDetectionCriteria skill

## When to use

- Does AUTH-88401 need prior authorization?
- Assemble the medical-necessity criteria for Priya Nair's knee replacement.
- Check whether CPT 77523 requires prior auth for Marcus Bell.

## Rules (single source of truth)

- The bundled `auth_detection_criteria_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_authdetectioncriteria`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference (e.g. AUTH-88401) only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `authReference` — Auth reference, patient name, or CPT code, e.g. AUTH-88401, 'Priya Nair', or 72148. Pass the word: list to see today's orders — never ask the user for an id.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_authdetectioncriteria` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 auth_detection_criteria_agent.py --data-json '{"_CANON": <items from list_authdetectioncriteria>}' --kwargs-json '{"authReference": "AUTH-88401, 'Priya Nair', or"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `AUTH-88401`.

---
name: submissiontracking
description: Submits the authorization request to the payer (portal or X12 278 with the assembled evidence packet, flagging expedited cases) and tracks every open authorization against its SLA clock — expedited 72h, standard 14 days — chasing pended documents and escalating approaching breaches to the UM queue. Requests live in Microsoft Dataverse. Identify a request by NATURAL reference: a patient name or AUTH- reference; never ask the user for an internal id. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# SubmissionTracking skill

## When to use

- What's the payer status of AUTH-88350?
- Track the SLA clock on Sam Okafor's spinal fusion request.
- Which prior-auth requests are close to an SLA breach?

## Rules (single source of truth)

- The bundled `submission_tracking_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_submissiontracking`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference (e.g. AUTH-88350) only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `authReference` — Auth reference or patient name, e.g. AUTH-88350 or 'Sam Okafor'. Pass the word: list for all open requests, or breaches for SLA-risk requests — never ask the user for an id.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_submissiontracking` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 submission_tracking_agent.py --data-json '{"_CANON": <items from list_submissiontracking>}' --kwargs-json '{"authReference": "AUTH-88350 or 'Sam Okafor"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `AUTH-88401`.

"""Denial Triage & Appeal Drafting / Peer-to-Peer Scheduling — steps 5-6 of the
Prior Authorization & Utilization Management process flow.

Step 5 — Denial Triage & Appeal Drafting: adverse determinations are triaged
by denial reason. Azure OpenAI drafts the appeal letter citing the payer's own
criteria and the member's clinical facts for UM nurse review. (Azure OpenAI,
Copilot Studio)

Step 6 — Peer-to-Peer Scheduling: when a physician review is required, Copilot
Studio negotiates a peer-to-peer slot between the ordering physician and the
payer medical director via calendar integration. (Copilot Studio,
Outlook / Graph)

Logic is REAL: a denied request gets a drafted appeal with the overturn
argument; a pended request needing physician review gets a proposed
peer-to-peer slot. Identify requests by NATURAL reference (patient name or
AUTH- ref). Data home: Microsoft Dataverse.
"""
try:
    from agents.basic_agent import BasicAgent
except ImportError:
    class BasicAgent:
        def __init__(self, name, metadata):
            self.name, self.metadata = name, metadata

_CANON = []  # data arrives at runtime from the MCP server (--data-json); the connector is the single source of truth


class DenialAppealPeer(BasicAgent):
    CAPIR = {"binding": {"system": "Microsoft Dataverse", "table": "accounts"}}
    TRIGGERS = [
        "Draft an appeal for the denied proton therapy request AUTH-88377.",
        "Schedule a peer-to-peer for Sam Okafor's spinal fusion.",
        "Why was Marcus Bell's authorization denied?",
    ]
    RESPONSE = ("Present records as plain text fields. NEVER invent, guess, or "
                "fabricate URLs, deep links, or Power Apps/Power BI links — the "
                "packaged demo data contains no links. Refer to records by their "
                "plain reference (e.g. AUTH-88377) only. Keep answers under ~130 "
                "words, professional markdown, no emojis.")
    SYNTHETIC_DATA = list(_CANON)

    def __init__(self):
        self.name = "DenialAppealPeer"
        self.metadata = {
            "name": self.name,
            "description": (
                "Triages adverse determinations by denial reason and drafts the "
                "appeal letter citing the payer's own criteria and the member's "
                "clinical facts, and — when a physician review is required — "
                "proposes a peer-to-peer slot between the ordering physician and "
                "the payer medical director. Requests live in Microsoft "
                "Dataverse. Identify a request by NATURAL reference: a patient "
                "name or AUTH- reference; never ask the user for an internal id."),
            "parameters": {
                "type": "object",
                "properties": {
                    "authReference": {
                        "type": "string",
                        "description": ("Auth reference or patient name, e.g. "
                                        "AUTH-88377 or 'Marcus Bell'. Pass the "
                                        "word: list to see requests needing "
                                        "appeal or peer-to-peer — never ask the "
                                        "user for an id.")},
                },
                "required": [],
            },
        }
        super().__init__(self.name, self.metadata)

    def _find(self, ref):
        low = ref.lower()
        return [a for a in _CANON if low == a["authReference"].lower()
                or low in a["patientName"].lower()]

    def perform(self, **kwargs):
        ref = str(kwargs.get("authReference") or "").strip()
        if not ref or ref.lower() == "list":
            work = [a for a in _CANON if a["track"] in ("denial", "peer-to-peer")]
            lines = ["## Requests needing appeal or peer-to-peer (Dataverse)"]
            lines += [f"{i}. **{a['authReference']}** — {a['patientName']}, "
                      f"{a['service']} — {a['track']}"
                      for i, a in enumerate(work, 1)]
            return "\n".join(lines)
        hits = self._find(ref)
        if not hits:
            return (f"No request matches `{ref}`. Say 'list' for requests "
                    "needing appeal or peer-to-peer.")
        a = hits[0]
        if a["track"] == "approved":
            return (f"## {a['authReference']} — {a['patientName']}\n"
                    "Approved on review — no appeal or peer-to-peer needed.")
        if a["track"] == "denial":
            return "\n".join([
                f"## {a['authReference']} — {a['patientName']}",
                f"- Service: {a['service']} | Payer: {a['payer']}",
                "",
                "### Step 5 — Denial triage & appeal draft",
                f"- Denial reason: {a['denialReason']}.",
                f"- **Drafted appeal:** {a['appeal']}.",
                "- Ready for UM nurse review before submission.",
            ])
        return "\n".join([
            f"## {a['authReference']} — {a['patientName']}",
            f"- Service: {a['service']} | Payer: {a['payer']}",
            "",
            "### Step 6 — Peer-to-peer scheduling",
            f"- {a['peerToPeer']}.",
            "- Invite ready to send on nurse confirmation.",
        ])


if __name__ == "__main__":  # thin-skill entrypoint (generated)
    import argparse as _ap
    import json as _js
    import sys as _sys
    _p = _ap.ArgumentParser(description="Run the DenialAppealPeer capability on "
                                        "records fetched from the MCP server.")
    _p.add_argument("--data-json", default="{}",
                    help="JSON object mapping dataset names to record arrays "
                         "fetched from the MCP server, e.g. "
                         "'{\"_CANON\": <items from list_denialappealpeer>}'")
    _p.add_argument("--kwargs-json", default="{}",
                    help="JSON object of perform() keyword arguments.")
    _a = _p.parse_args()
    try:
        _data = _js.loads(_a.data_json)
        _kw = _js.loads(_a.kwargs_json)
    except Exception as _e:
        print("Invalid JSON argument: %s" % _e)
        _sys.exit(2)
    _g = globals()
    for _name, _rows in (_data or {}).items():
        if _name in _g and isinstance(_rows, (list, dict)):
            _g[_name] = _rows
        for _obj in list(_g.values()):
            if isinstance(_obj, type) and hasattr(_obj, _name):
                setattr(_obj, _name, _rows)
    def _have(_n):
        if _g.get(_n):
            return True
        return any(isinstance(_o, type) and getattr(_o, _n, None)
                   for _o in list(_g.values()))
    _missing = [n for n in ['_CANON'] if not _have(n)]
    if _missing:
        print("No data provided for: %s. Fetch records from the MCP server "
              "(list_denialappealpeer) first and pass them via --data-json."
              % ", ".join(_missing))
        _sys.exit(3)
    print(DenialAppealPeer().perform(**_kw))

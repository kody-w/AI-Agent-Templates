---
name: denialappealpeer
description: Triages adverse determinations by denial reason and drafts the appeal letter citing the payer's own criteria and the member's clinical facts, and — when a physician review is required — proposes a peer-to-peer slot between the ordering physician and the payer medical director. Requests live in Microsoft Dataverse. Identify a request by NATURAL reference: a patient name or AUTH- reference; never ask the user for an internal id. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# DenialAppealPeer skill

## When to use

- Draft an appeal for the denied proton therapy request AUTH-88377.
- Schedule a peer-to-peer for Sam Okafor's spinal fusion.
- Why was Marcus Bell's authorization denied?

## Rules (single source of truth)

- The bundled `denial_appeal_peer_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_denialappealpeer`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference (e.g. AUTH-88377) only. Keep answers under ~130 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `authReference` — Auth reference or patient name, e.g. AUTH-88377 or 'Marcus Bell'. Pass the word: list to see requests needing appeal or peer-to-peer — never ask the user for an id.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_denialappealpeer` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 denial_appeal_peer_agent.py --data-json '{"_CANON": <items from list_denialappealpeer>}' --kwargs-json '{"authReference": "AUTH-88377 or 'Marcus Bell"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `AUTH-88377`.

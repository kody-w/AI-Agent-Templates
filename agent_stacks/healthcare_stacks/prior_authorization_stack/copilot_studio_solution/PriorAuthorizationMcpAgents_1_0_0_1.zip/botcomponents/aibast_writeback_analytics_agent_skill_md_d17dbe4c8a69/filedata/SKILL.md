---
name: writebackanalytics
description: Writes approved determinations back to the EHR and scheduling system — auth number, validity window, and unit limits so care books within the authorized scope — and reports UM analytics: approval and overturn rates, average turnaround by payer and service line, and SLA performance. Requests live in Microsoft Dataverse. Identify a request by NATURAL reference: a patient name or AUTH- reference; pass 'analytics' for the governance scoreboard. Never ask the user for an internal id. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# WritebackAnalytics skill

## When to use

- Write back the approval for AUTH-88394 to the EHR.
- What's the auth number and validity window for Priya Nair's knee replacement?
- Show the UM analytics: approval rate and average turnaround by payer.

## Rules (single source of truth)

- The bundled `writeback_analytics_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_writebackanalytics`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference (e.g. AUTH-88394) only. Keep answers under ~130 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `authReference` — Auth reference or patient name, e.g. AUTH-88394 or 'Priya Nair'. Pass the word: analytics for the UM scoreboard, or list for all determinations — never ask the user for an id.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_writebackanalytics` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 writeback_analytics_agent.py --data-json '{"_CANON": <items from list_writebackanalytics>}' --kwargs-json '{"authReference": "AUTH-88394 or 'Priya Nair"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `AUTH-88401`.

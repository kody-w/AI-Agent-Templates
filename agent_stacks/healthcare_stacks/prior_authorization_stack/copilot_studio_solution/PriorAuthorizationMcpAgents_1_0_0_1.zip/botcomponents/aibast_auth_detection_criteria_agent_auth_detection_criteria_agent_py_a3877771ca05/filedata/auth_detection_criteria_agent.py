"""Auth Requirement Detection & Clinical Criteria Assembly — steps 1-2 of the
Prior Authorization & Utilization Management process flow.

Step 1 — Auth Requirement Detection: when an order is placed, Copilot Studio
checks the payer rules engine to determine whether the CPT/HCPCS code and plan
require prior authorization, honouring gold-carding exemptions for
high-approval providers. (Copilot Studio, Payer Rules Engine)

Step 2 — Clinical Criteria Assembly: Azure OpenAI extracts the supporting
clinical evidence from the EHR — diagnoses, prior conservative treatment,
imaging — and maps it against the payer's medical-necessity criteria
(MCG / InterQual) for the requested service. (Azure OpenAI, EHR System)

Rules are REAL and deterministic: a gold-carded CPT/plan skips review; other
orders require prior auth and get a criteria packet assembled. Identify
requests by NATURAL reference (patient name, CPT code, or AUTH- ref). Data
home: Microsoft Dataverse.
"""
try:
    from agents.basic_agent import BasicAgent
except ImportError:
    class BasicAgent:
        def __init__(self, name, metadata):
            self.name, self.metadata = name, metadata

# The canonical prior-auth book — the SAME requests flow through the sibling
# agents (submission & tracking, denial & peer-to-peer, write-back & analytics)
# so every hop tells one coherent utilization-management story.
_CANON = []  # data arrives at runtime from the MCP server (--data-json); the connector is the single source of truth


class AuthDetectionCriteria(BasicAgent):
    CAPIR = {"binding": {"system": "Microsoft Dataverse", "table": "accounts"}}
    TRIGGERS = [
        "Does AUTH-88401 need prior authorization?",
        "Assemble the medical-necessity criteria for Priya Nair's knee replacement.",
        "Check whether CPT 77523 requires prior auth for Marcus Bell.",
    ]
    RESPONSE = ("Present records as plain text fields. NEVER invent, guess, or "
                "fabricate URLs, deep links, or Power Apps/Power BI links — the "
                "packaged demo data contains no links. Refer to records by their "
                "plain reference (e.g. AUTH-88401) only. Keep answers under ~120 "
                "words, professional markdown, no emojis.")
    SYNTHETIC_DATA = list(_CANON)

    def __init__(self):
        self.name = "AuthDetectionCriteria"
        self.metadata = {
            "name": self.name,
            "description": (
                "Detects whether a placed order requires prior authorization by "
                "checking the CPT/HCPCS code and plan against the payer rules "
                "engine (honouring gold-carding exemptions), then assembles the "
                "clinical-evidence packet from the EHR and maps it against the "
                "payer's MCG/InterQual medical-necessity criteria. Requests live "
                "in Microsoft Dataverse. Identify a request by NATURAL reference: "
                "a patient name, CPT code, or AUTH- reference; never ask the user "
                "for an internal id."),
            "parameters": {
                "type": "object",
                "properties": {
                    "authReference": {
                        "type": "string",
                        "description": ("Auth reference, patient name, or CPT "
                                        "code, e.g. AUTH-88401, 'Priya Nair', "
                                        "or 72148. Pass the word: list to see "
                                        "today's orders — never ask the user "
                                        "for an id.")},
                },
                "required": [],
            },
        }
        super().__init__(self.name, self.metadata)

    def _find(self, ref):
        low = ref.lower()
        return [a for a in _CANON if low == a["authReference"].lower()
                or low in a["patientName"].lower() or low == a["cpt"]]

    def perform(self, **kwargs):
        ref = str(kwargs.get("authReference") or "").strip()
        if not ref or ref.lower() == "list":
            lines = ["## Orders under prior-auth review — today (Dataverse)"]
            lines += [f"{i}. **{a['authReference']}** — {a['patientName']}, "
                      f"{a['service']} (CPT {a['cpt']}), {a['payer']} — "
                      f"{'gold-carded' if a['goldCarded'] else a['urgency']}"
                      for i, a in enumerate(_CANON, 1)]
            lines.append("")
            lines.append("Name a request for its auth-requirement and "
                         "medical-necessity detail.")
            return "\n".join(lines)
        hits = self._find(ref)
        if not hits:
            return (f"No order matches `{ref}`. Say 'list' for today's orders "
                    "under review.")
        a = hits[0]
        lines = [
            f"## {a['authReference']} — {a['patientName']}",
            f"- Service: {a['service']} (CPT {a['cpt']}) | Payer: {a['payer']} "
            f"| Urgency: {a['urgency']}",
            "",
            "### Step 1 — Auth requirement (payer rules engine)",
            f"- {a['requirement']}.",
        ]
        if a["goldCarded"]:
            lines.append("- No review needed; order proceeds to scheduling.")
            return "\n".join(lines)
        lines += [
            "",
            "### Step 2 — Clinical criteria assembly (EHR → MCG/InterQual)",
            f"- {a['criteria']}.",
            f"- Assembled evidence packet ready for payer submission "
            f"({a['authReference']}).",
        ]
        return "\n".join(lines)


if __name__ == "__main__":  # thin-skill entrypoint (generated)
    import argparse as _ap
    import json as _js
    import sys as _sys
    _p = _ap.ArgumentParser(description="Run the AuthDetectionCriteria capability on "
                                        "records fetched from the MCP server.")
    _p.add_argument("--data-json", default="{}",
                    help="JSON object mapping dataset names to record arrays "
                         "fetched from the MCP server, e.g. "
                         "'{\"_CANON\": <items from list_authdetectioncriteria>}'")
    _p.add_argument("--kwargs-json", default="{}",
                    help="JSON object of perform() keyword arguments.")
    _a = _p.parse_args()
    try:
        _data = _js.loads(_a.data_json)
        _kw = _js.loads(_a.kwargs_json)
    except Exception as _e:
        print("Invalid JSON argument: %s" % _e)
        _sys.exit(2)
    _g = globals()
    for _name, _rows in (_data or {}).items():
        if _name in _g and isinstance(_rows, (list, dict)):
            _g[_name] = _rows
        for _obj in list(_g.values()):
            if isinstance(_obj, type) and hasattr(_obj, _name):
                setattr(_obj, _name, _rows)
    def _have(_n):
        if _g.get(_n):
            return True
        return any(isinstance(_o, type) and getattr(_o, _n, None)
                   for _o in list(_g.values()))
    _missing = [n for n in ['_CANON'] if not _have(n)]
    if _missing:
        print("No data provided for: %s. Fetch records from the MCP server "
              "(list_authdetectioncriteria) first and pass them via --data-json."
              % ", ".join(_missing))
        _sys.exit(3)
    print(AuthDetectionCriteria().perform(**_kw))

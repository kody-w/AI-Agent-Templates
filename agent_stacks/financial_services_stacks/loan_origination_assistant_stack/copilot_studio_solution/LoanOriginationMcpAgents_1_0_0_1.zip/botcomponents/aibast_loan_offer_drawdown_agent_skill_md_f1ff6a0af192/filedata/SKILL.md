---
name: loanofferdrawdown
description: Presents the personalised loan offer for an approved applicant — APR, term, and a correctly computed monthly repayment, optimised for conversion within risk appetite — and on explicit acceptance runs automated drawdown in the core banking system with funds credited inside the regulatory timeframe (T+1). Offer records live in Microsoft Dataverse. Identify offers by NATURAL reference: applicant name or LN- reference. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# LoanOfferDrawdown skill

## When to use

- Show Loan Offer Drawdown for applicantname LN-73186.
- Present the offer for Elena Rossi
- Elena accepts the offer — run drawdown

## Rules (single source of truth)

- The bundled `loan_offer_drawdown_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_loanofferdrawdown`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference (e.g. LN-73214) only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `applicantName` — Applicant name or LN- reference, e.g. 'Elena Rossi' or LN-73186. Pass the word: list to see every open offer - never ask the user for an id.
- `accepted` — Set to 'yes' when the customer accepts, to run drawdown (optional).

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_loanofferdrawdown` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 loan_offer_drawdown_agent.py --data-json '{"_CANON": <items from list_loanofferdrawdown>}' --kwargs-json '{"applicantName": "Elena Rossi' or LN-73186. Pa"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `LN-73186`.

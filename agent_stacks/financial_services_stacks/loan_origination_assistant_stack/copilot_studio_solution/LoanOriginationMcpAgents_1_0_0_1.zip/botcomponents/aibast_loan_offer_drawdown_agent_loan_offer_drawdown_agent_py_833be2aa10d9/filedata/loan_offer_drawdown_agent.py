"""Offer Presentation & Drawdown Processing — steps 5-6 of the Loan
Origination & Credit Decisioning process flow.

Step 5 — Offer Presentation: Approved applicants receive a personalised
offer via Copilot Studio. The offer presentation is dynamically optimised
for conversion while staying within risk appetite. (Copilot Studio)

Step 6 — Drawdown Processing: Accepted offers trigger automated drawdown
processing in the core banking system. Funds are credited within the
required regulatory timeframe. (Power Automate, Core Banking System)

Repayments use REAL annuity maths: payment = P*r / (1 - (1+r)^-n) at the
offer's monthly rate over the term. Offer state lives in Microsoft
Dataverse; drawdown runs only on explicit acceptance.
"""
try:
    from agents.basic_agent import BasicAgent
except ImportError:
    class BasicAgent:
        def __init__(self, name, metadata):
            self.name, self.metadata = name, metadata

# Canonical offers — approved applicants from the credit-decision agent.
_CANON = []  # data arrives at runtime from the MCP server (--data-json); the connector is the single source of truth


def _repayment(amount, apr, months):
    """Standard annuity payment at apr% nominal, monthly compounding."""
    r = apr / 100.0 / 12.0
    if r == 0:
        return round(amount / months, 2)
    return round(amount * r / (1.0 - (1.0 + r) ** -months), 2)


class LoanOfferDrawdown(BasicAgent):
    CAPIR = {"binding": {"system": "Microsoft Dataverse", "table": "accounts"}}
    TRIGGERS = [
        'Show Loan Offer Drawdown for applicantname LN-73186.',
        'Present the offer for Elena Rossi',
        'Elena accepts the offer — run drawdown',
    ]
    RESPONSE = ("Present records as plain text fields. NEVER invent, guess, or "
                "fabricate URLs, deep links, or Power Apps/Power BI links — the "
                "packaged demo data contains no links. Refer to records by their "
                "plain reference (e.g. LN-73214) only. Keep answers under ~120 "
                "words, professional markdown, no emojis.")
    SYNTHETIC_DATA = [
        {**o, "monthlyRepayment": _repayment(o["loanAmount"], o["apr"],
                                             o["termMonths"])}
        for o in _CANON
    ]

    def __init__(self):
        self.name = "LoanOfferDrawdown"
        self.metadata = {
            "name": self.name,
            "description": (
                "Presents the personalised loan offer for an approved "
                "applicant — APR, term, and a correctly computed monthly "
                "repayment, optimised for conversion within risk appetite — "
                "and on explicit acceptance runs automated drawdown in the "
                "core banking system with funds credited inside the "
                "regulatory timeframe (T+1). Offer records live in Microsoft "
                "Dataverse. Identify offers by NATURAL reference: applicant "
                "name or LN- reference."),
            "parameters": {
                "type": "object",
                "properties": {
                    "applicantName": {
                        "type": "string",
                        "description": ("Applicant name or LN- reference, "
                                        "e.g. 'Elena Rossi' or LN-73186. "
                                        "Pass the word: list to see every "
                                        "open offer - never ask the user "
                                        "for an id.")},
                    "accepted": {
                        "type": "string",
                        "description": ("Set to 'yes' when the customer "
                                        "accepts, to run drawdown "
                                        "(optional).")},
                },
                "required": [],
            },
        }
        super().__init__(self.name, self.metadata)

    def perform(self, **kwargs):
        ref = str(kwargs.get("applicantName") or "").strip()
        accepted = str(kwargs.get("accepted") or "").strip().lower() in (
            "yes", "y", "true", "accept", "accepted")
        if not ref or ref.lower() == "list":
            lines = ["## Offer book (Dataverse)"]
            for o in _CANON:
                pay = _repayment(o["loanAmount"], o["apr"], o["termMonths"])
                lines.append(f"- **{o['applicationId']}** "
                             f"{o['applicantName']} £{o['loanAmount']:,} @ "
                             f"{o['apr']}% x {o['termMonths']}mo "
                             f"(£{pay:,.2f}/mo) — {o['offerStatus']}")
            lines.append("")
            lines.append("Name an applicant to present or act on their "
                         "offer.")
            return "\n".join(lines)
        low = ref.lower()
        hits = [o for o in _CANON if low in o["applicantName"].lower()
                or low == o["applicationId"].lower()]
        if not hits:
            return (f"No offer matches `{ref}`. Offers exist for: "
                    + ", ".join(o["applicantName"] for o in _CANON)
                    + ". Say 'list' for the offer book.")
        o = hits[0]
        pay = _repayment(o["loanAmount"], o["apr"], o["termMonths"])
        total = round(pay * o["termMonths"], 2)
        lines = [
            f"## Personalised offer — {o['applicationId']} "
            f"({o['applicantName']})",
            f"- Amount: £{o['loanAmount']:,}  |  APR: {o['apr']}% "
            "representative",
            f"- Term: {o['termMonths']} months  |  Monthly repayment: "
            f"**£{pay:,.2f}**  |  Total repayable: £{total:,.2f}",
            f"- Status: {o['offerStatus']}",
        ]
        if accepted and "presented" in o["offerStatus"]:
            lines += [
                "",
                "### Drawdown processed",
                f"- Core banking instruction {o['applicationId']}-DD "
                "executed via Power Automate.",
                "- Funds credited to the nominated account inside the "
                "regulatory timeframe (T+1).",
                "- Welcome pack and first-repayment schedule issued.",
            ]
        elif accepted:
            lines += ["", f"This offer is not open for acceptance "
                          f"({o['offerStatus']})."]
        else:
            lines += ["", "Say 'accept the offer' to trigger drawdown, or "
                          "ask for the portfolio scoreboard."]
        return "\n".join(lines)


if __name__ == "__main__":  # thin-skill entrypoint (generated)
    import argparse as _ap
    import json as _js
    import sys as _sys
    _p = _ap.ArgumentParser(description="Run the LoanOfferDrawdown capability on "
                                        "records fetched from the MCP server.")
    _p.add_argument("--data-json", default="{}",
                    help="JSON object mapping dataset names to record arrays "
                         "fetched from the MCP server, e.g. "
                         "'{\"_CANON\": <items from list_loanofferdrawdown>}'")
    _p.add_argument("--kwargs-json", default="{}",
                    help="JSON object of perform() keyword arguments.")
    _a = _p.parse_args()
    try:
        _data = _js.loads(_a.data_json)
        _kw = _js.loads(_a.kwargs_json)
    except Exception as _e:
        print("Invalid JSON argument: %s" % _e)
        _sys.exit(2)
    _g = globals()
    for _name, _rows in (_data or {}).items():
        if _name in _g and isinstance(_rows, (list, dict)):
            _g[_name] = _rows
        for _obj in list(_g.values()):
            if isinstance(_obj, type) and hasattr(_obj, _name):
                setattr(_obj, _name, _rows)
    def _have(_n):
        if _g.get(_n):
            return True
        return any(isinstance(_o, type) and getattr(_o, _n, None)
                   for _o in list(_g.values()))
    _missing = [n for n in ['_CANON'] if not _have(n)]
    if _missing:
        print("No data provided for: %s. Fetch records from the MCP server "
              "(list_loanofferdrawdown) first and pass them via --data-json."
              % ", ".join(_missing))
        _sys.exit(3)
    print(LoanOfferDrawdown().perform(**_kw))

---
name: creditdecisionengine
description: Runs the automated credit scorecard (bureau + application + behavioural scores, from the Credit Bureau API) and the concurrent Azure AI fraud risk assessment (identity, device, application-level indicators) for a loan application, returning APPROVE / REFER / DECLINE with the rationale. Decisions are recorded in Microsoft Dataverse. Identify the case by NATURAL reference: applicant name or LN- reference. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# CreditDecisionEngine skill

## When to use

- Show Credit Decision Engine for applicantname LN-73214.
- Run the credit decision for Elena Rossi
- Which applications are on the decision queue?

## Rules (single source of truth)

- The bundled `credit_decision_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_creditdecisionengine`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference (e.g. LN-73214) only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `applicantName` — Applicant name or LN- reference, e.g. 'Elena Rossi' or LN-73186. Pass the word: list to see every pending decision - never ask the user for an id.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_creditdecisionengine` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 credit_decision_agent.py --data-json '{"_CANON": <items from list_creditdecisionengine>}' --kwargs-json '{"applicantName": "Elena Rossi' or LN-73186. Pa"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `LN-73214`.

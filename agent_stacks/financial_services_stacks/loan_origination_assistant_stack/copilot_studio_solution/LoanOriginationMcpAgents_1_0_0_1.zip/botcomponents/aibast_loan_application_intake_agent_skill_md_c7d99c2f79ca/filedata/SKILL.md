---
name: loanapplicationintake
description: Captures loan applications from any channel (digital or branch) and builds the consented Open Banking affordability view — verified income, expenditure bands, and monthly surplus — for each applicant. Application data lives in Microsoft Dataverse. Identify applicants by NATURAL reference: a name like 'Priya Sharma' or a reference like LN-73214; never ask the user for internal identifiers. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# LoanApplicationIntake skill

## When to use

- Show Loan Application Intake for applicantname LN-73214.
- Show me the application pipeline
- Capture a new loan application for Robin Hale, £20,000, home improvement

## Rules (single source of truth)

- The bundled `loan_application_intake_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_loanapplicationintake`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference (e.g. LN-73214) only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `applicantName` — Applicant name or LN- reference, e.g. 'Priya Sharma' or LN-73214. Pass the word: list to see the application pipeline - never ask the user for an id.
- `loanAmount` — Requested amount in GBP for a NEW application (optional).
- `loanPurpose` — Purpose of a NEW loan (optional).
- `channel` — Channel for a NEW application: web, mobile, or branch (optional).
- `monthlyIncome` — Stated monthly income for a NEW application (optional).

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_loanapplicationintake` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 loan_application_intake_agent.py --data-json '{"_CANON": <items from list_loanapplicationintake>}' --kwargs-json '{"applicantName": "Priya Sharma' or LN-73214. P"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `LN-73214`.

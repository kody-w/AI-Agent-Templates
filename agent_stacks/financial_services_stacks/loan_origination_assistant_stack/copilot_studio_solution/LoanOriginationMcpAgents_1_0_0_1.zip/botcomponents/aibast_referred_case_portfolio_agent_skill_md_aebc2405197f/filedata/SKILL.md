---
name: referredcaseportfolio
description: Works the underwriter referral queue and the governance portfolio scoreboard, both held in Microsoft Dataverse. With no inputs it lists the referred applications with their full AI-generated assessments; given a case and a decision it records the outcome and rationale for model feedback; ask for 'portfolio' to get the governance scoreboard (approval rates, bad debt by vintage, model performance). The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# ReferredCasePortfolio skill

## When to use

- Show Referred Case Portfolio for casereference LN-73214.
- Which referred applications await an underwriter?
- Show me the portfolio governance scoreboard

## Rules (single source of truth)

- The bundled `referred_case_portfolio_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_referredcaseportfolio`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference (e.g. LN-73214) only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `caseReference` — Referred case to open or decide, e.g. LN-73214 or an applicant name. Pass the word: list for the queue - never ask the user for an id.
- `decision` — Underwriter decision to record: approve or decline (optional).
- `rationale` — Decision rationale, captured for model feedback (optional).
- `view` — Set to 'portfolio' for the governance MI scoreboard (optional).

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_referredcaseportfolio` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 referred_case_portfolio_agent.py --data-json '{"_QUEUE": <items from list_referredcaseportfolio>}' --kwargs-json '{"caseReference": "LN-73214 or an applicant nam"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `LN-73214`.

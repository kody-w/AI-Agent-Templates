"""Customer Query Resolution & Payments Analytics — steps 7-8 of the
Payments Operations Excellence process flow.

Step 7 — Customer Query Resolution: Payment tracking queries from customers
and corporates are resolved with real-time payment status from the payment
platform. (Copilot Studio, Payment Platform)

Step 8 — Payments Analytics: Volumes, values, STP rates, and scheme
compliance metrics are tracked across all payment types and rails.
(Power BI)

Tracking statuses cohere with the rest of the suite: the sanctions hold
(PAY-731162), the fraud hold (PAY-731130), and the settled/in-flight
payments all match the ingestion, exception, and fraud agents' canon; the
scoreboard's 4 open exceptions and 3 holds are exactly those items. Data
home: Microsoft Dataverse.
"""
try:
    from agents.basic_agent import BasicAgent
except ImportError:
    class BasicAgent:
        def __init__(self, name, metadata):
            self.name, self.metadata = name, metadata

_TRACKING = []  # data arrives at runtime from the MCP server (--data-json); the connector is the single source of truth

_SCOREBOARD = [
    ("Volume today", "41,208 instructions"),
    ("Value today", "£1.92B across all rails"),
    ("STP rate", "96.8% (target 96.5%)"),
    ("Open STP exceptions", "4 (PAY-731205, PAY-731198, PAY-731184, "
                            "PAY-731171)"),
    ("Payments on hold", "3 (1 sanctions, 1 duplicate, 1 fraud)"),
    ("By rail", "Faster Payments 31,455 | SEPA 6,210 | CHAPS 2,481 | "
                "SWIFT 1,062"),
    ("Scheme compliance", "CHAPS same-day 100% | SEPA SCT Inst 9.4s avg "
                          "settlement"),
]


class PaymentQueryAnalytics(BasicAgent):
    CAPIR = {"binding": {"system": "Microsoft Dataverse", "table": "accounts"}}
    TRIGGERS = [
        "Show Payment Query Analytics for paymentreference PAY-731150.",
        "Where is the payment to Woodgrove Bank?",
        "Show me today's payments analytics scoreboard",
    ]
    RESPONSE = ("Present records as plain text fields. NEVER invent, guess, "
                "or fabricate URLs, deep links, or Power Apps/Power BI links "
                "— the packaged demo data contains no links. Refer to records "
                "by their plain reference (e.g. PAY-731150) only. Keep "
                "answers under ~120 words, professional markdown, no emojis.")
    SYNTHETIC_DATA = list(_TRACKING)

    def __init__(self):
        self.name = "PaymentQueryAnalytics"
        self.metadata = {
            "name": self.name,
            "description": (
                "Resolves 'where is my payment?' tracking queries with the "
                "real-time status and timeline from the payment platform "
                "(records in Microsoft Dataverse), and serves the payments "
                "analytics scoreboard — volumes, values, STP rate, holds, "
                "and scheme compliance across all rails. Identify a payment "
                "by NATURAL reference (PAY- reference or beneficiary name); "
                "ask for 'analytics' for the scoreboard; never ask the user "
                "for internal identifiers."),
            "parameters": {
                "type": "object",
                "properties": {
                    "paymentReference": {
                        "type": "string",
                        "description": ("Payment to track, e.g. PAY-731150 "
                                        "or 'Woodgrove Bank'. Pass the "
                                        "word: list to see every tracked "
                                        "payment - never ask the user for "
                                        "an id.")},
                    "view": {
                        "type": "string",
                        "description": ("Set to 'analytics' for the "
                                        "payments scoreboard (optional).")},
                },
                "required": [],
            },
        }
        super().__init__(self.name, self.metadata)

    def perform(self, **kwargs):
        view = str(kwargs.get("view") or "").strip().lower()
        ref = str(kwargs.get("paymentReference") or "").strip()
        low = ref.lower()
        if view.startswith("analytic") or low == "analytics":
            lines = ["## Payments analytics — today's scoreboard"]
            lines += [f"- {k}: {v}" for k, v in _SCOREBOARD]
            lines.append("")
            lines.append("Name a payment reference or beneficiary to track "
                         "an individual payment.")
            return "\n".join(lines)
        if not ref or low == "list":
            lines = ["## Tracked payments (real-time status)"]
            lines += [f"{i}. **{t['paymentReference']}** — "
                      f"{t['beneficiaryName']}, {t['amount']} via "
                      f"{t['rail']} — **{t['trackStatus']}**"
                      for i, t in enumerate(_TRACKING, 1)]
            lines.append("")
            lines.append("Open one for its timeline, or ask for "
                         "'analytics' for the scoreboard.")
            return "\n".join(lines)
        hit = next((t for t in _TRACKING
                    if low == t["paymentReference"].lower()
                    or low in t["beneficiaryName"].lower()), None)
        if not hit:
            return (f"No tracked payment matches `{ref}`. Say 'list' for "
                    "every tracked payment or 'analytics' for the "
                    "scoreboard.")
        return "\n".join([
            f"## Payment tracking — {hit['paymentReference']} "
            f"({hit['beneficiaryName']})",
            f"- Amount: {hit['amount']} | Rail: {hit['rail']}",
            f"- Real-time status: **{hit['trackStatus']}**",
            f"- Timeline: {hit['timeline']}.",
            "",
            "The beneficiary bank confirmation reference is available on "
            "request.",
        ])


if __name__ == "__main__":  # thin-skill entrypoint (generated)
    import argparse as _ap
    import json as _js
    import sys as _sys
    _p = _ap.ArgumentParser(description="Run the PaymentQueryAnalytics capability on "
                                        "records fetched from the MCP server.")
    _p.add_argument("--data-json", default="{}",
                    help="JSON object mapping dataset names to record arrays "
                         "fetched from the MCP server, e.g. "
                         "'{\"_TRACKING\": <items from list_paymentqueryanalytics>}'")
    _p.add_argument("--kwargs-json", default="{}",
                    help="JSON object of perform() keyword arguments.")
    _a = _p.parse_args()
    try:
        _data = _js.loads(_a.data_json)
        _kw = _js.loads(_a.kwargs_json)
    except Exception as _e:
        print("Invalid JSON argument: %s" % _e)
        _sys.exit(2)
    _g = globals()
    for _name, _rows in (_data or {}).items():
        if _name in _g and isinstance(_rows, (list, dict)):
            _g[_name] = _rows
        for _obj in list(_g.values()):
            if isinstance(_obj, type) and hasattr(_obj, _name):
                setattr(_obj, _name, _rows)
    def _have(_n):
        if _g.get(_n):
            return True
        return any(isinstance(_o, type) and getattr(_o, _n, None)
                   for _o in list(_g.values()))
    _missing = [n for n in ['_TRACKING'] if not _have(n)]
    if _missing:
        print("No data provided for: %s. Fetch records from the MCP server "
              "(list_paymentqueryanalytics) first and pass them via --data-json."
              % ", ".join(_missing))
        _sys.exit(3)
    print(PaymentQueryAnalytics().perform(**_kw))

"""Payment Ingestion & Sanctions Screening — steps 1-2 of the Payments
Operations Excellence process flow.

Step 1 — Payment Ingestion: All payment instructions (CHAPS, Faster
Payments, SEPA, SWIFT) are ingested and validated by Azure AI against the
relevant scheme rules and sanction lists. (Azure AI, Payment Platform)

Step 2 — Sanctions & Screening: Every payment is screened against OFAC,
HMT, and EU sanctions lists in real time. Hits are routed to compliance
analysts for review. (Sanctions Screening, Copilot Studio)

Screening rules are REAL and deterministic: a payment flagged in the canon
as a potential list match is HELD with a compliance case reference
(<ref>-SCR); everything else clears and releases. Identify payments by
NATURAL reference (beneficiary name or PAY- ref). Data home: Microsoft
Dataverse.
"""
try:
    from agents.basic_agent import BasicAgent
except ImportError:
    class BasicAgent:
        def __init__(self, name, metadata):
            self.name, self.metadata = name, metadata

# The canonical payments book — the SAME instructions flow through the
# sibling agents (exceptions & recon, correspondent & fraud, tracking &
# analytics) so every hop tells one coherent story.
_CANON = []  # data arrives at runtime from the MCP server (--data-json); the connector is the single source of truth

_RAILS = ("CHAPS", "Faster Payments", "SEPA", "SWIFT")


class PaymentIngestionScreening(BasicAgent):
    CAPIR = {"binding": {"system": "Microsoft Dataverse", "table": "accounts"}}
    TRIGGERS = [
        "Show Payment Ingestion Screening for paymentreference PAY-731162.",
        "Screen the payment to Contoso Pharmaceuticals",
        "Ingest a new payment: GBP 25,000 to Northwind Traders on Faster Payments",
    ]
    RESPONSE = ("Present records as plain text fields. NEVER invent, guess, or "
                "fabricate URLs, deep links, or Power Apps/Power BI links — the "
                "packaged demo data contains no links. Refer to records by their "
                "plain reference (e.g. LN-73214) only. Keep answers under ~120 "
                "words, professional markdown, no emojis.")
    SYNTHETIC_DATA = list(_CANON)

    def __init__(self):
        self.name = "PaymentIngestionScreening"
        self.metadata = {
            "name": self.name,
            "description": (
                "Ingests payment instructions on any rail (CHAPS, Faster "
                "Payments, SEPA, SWIFT), validates them against the scheme "
                "rules, and screens every payment in real time against the "
                "OFAC, HMT, and EU sanctions lists — holding any potential "
                "match with a compliance case reference. Payment records "
                "live in Microsoft Dataverse. Identify payments by NATURAL "
                "reference: a beneficiary name or a PAY- reference; never "
                "ask the user for internal identifiers."),
            "parameters": {
                "type": "object",
                "properties": {
                    "paymentReference": {
                        "type": "string",
                        "description": ("Payment reference or beneficiary "
                                        "name, e.g. PAY-731162 or 'Contoso "
                                        "Pharmaceuticals'. Pass the word: "
                                        "list to see today's ingested "
                                        "payments - never ask the user for "
                                        "an id.")},
                    "beneficiaryName": {
                        "type": "string",
                        "description": ("Beneficiary for a NEW payment "
                                        "(optional).")},
                    "amount": {
                        "type": "number",
                        "description": "Amount for a NEW payment (optional)."},
                    "currency": {
                        "type": "string",
                        "description": ("Currency for a NEW payment: GBP, "
                                        "EUR, USD (optional).")},
                    "rail": {
                        "type": "string",
                        "description": ("Rail for a NEW payment: CHAPS, "
                                        "Faster Payments, SEPA, or SWIFT "
                                        "(optional).")},
                },
                "required": [],
            },
        }
        super().__init__(self.name, self.metadata)

    def _find(self, ref):
        low = ref.lower()
        return [p for p in _CANON if low == p["paymentReference"].lower()
                or low in p["beneficiaryName"].lower()]

    def perform(self, **kwargs):
        ref = str(kwargs.get("paymentReference")
                  or kwargs.get("beneficiaryName") or "").strip()
        if not ref or ref.lower() == "list":
            lines = ["## Ingested payments — today (Dataverse)"]
            lines += [f"{i}. **{p['paymentReference']}** — "
                      f"{p['beneficiaryName']}, {p['currency']} "
                      f"{p['amount']:,.2f} via {p['rail']} — "
                      f"{p['screenStatus']}"
                      for i, p in enumerate(_CANON, 1)]
            lines.append("")
            lines.append("Name a payment for its screening detail, or give "
                         "me a beneficiary, amount, and rail to ingest a "
                         "new instruction.")
            return "\n".join(lines)
        hits = self._find(ref)
        if not hits and kwargs.get("amount"):
            amount = float(kwargs.get("amount"))
            ccy = (kwargs.get("currency") or "GBP").upper()
            rail = kwargs.get("rail") or "Faster Payments"
            next_ref = "PAY-%d" % (max(int(p["paymentReference"][4:])
                                       for p in _CANON) + 9)
            return "\n".join([
                f"## Payment ingested — {next_ref}",
                f"- Beneficiary: {ref} | Amount: {ccy} {amount:,.2f} | "
                f"Rail: {rail}",
                "- Scheme validation: PASSED (format, cut-off, and scheme "
                "rules checked by Azure AI).",
                "",
                "### Real-time sanctions screening (OFAC / HMT / EU)",
                "- No matches on any list.",
                f"- {next_ref} released to the payment platform for onward "
                "processing.",
            ])
        if not hits:
            return (f"No payment matches `{ref}`. Say 'list' for today's "
                    "ingested payments.")
        p = hits[0]
        lines = [
            f"## {p['paymentReference']} — {p['beneficiaryName']}",
            f"- Amount: {p['currency']} {p['amount']:,.2f} | Rail: "
            f"{p['rail']}",
            "- Scheme validation: PASSED (Azure AI).",
            "",
            "### Real-time sanctions screening (OFAC / HMT / EU)",
        ]
        if p["sanctionsMatch"] != "none":
            lines += [
                f"- **POTENTIAL MATCH** — {p['sanctionsMatch']}.",
                f"- Payment **HELD**; {p['screenStatus'].split(chr(8212))[-1].strip()} "
                "routed to the compliance analyst queue.",
                "- Release or reject on analyst review.",
            ]
        else:
            lines += [
                "- No matches on OFAC, HMT, or EU lists.",
                f"- Status: {p['screenStatus']}.",
            ]
        return "\n".join(lines)


if __name__ == "__main__":  # thin-skill entrypoint (generated)
    import argparse as _ap
    import json as _js
    import sys as _sys
    _p = _ap.ArgumentParser(description="Run the PaymentIngestionScreening capability on "
                                        "records fetched from the MCP server.")
    _p.add_argument("--data-json", default="{}",
                    help="JSON object mapping dataset names to record arrays "
                         "fetched from the MCP server, e.g. "
                         "'{\"_CANON\": <items from list_paymentingestionscreening>}'")
    _p.add_argument("--kwargs-json", default="{}",
                    help="JSON object of perform() keyword arguments.")
    _a = _p.parse_args()
    try:
        _data = _js.loads(_a.data_json)
        _kw = _js.loads(_a.kwargs_json)
    except Exception as _e:
        print("Invalid JSON argument: %s" % _e)
        _sys.exit(2)
    _g = globals()
    for _name, _rows in (_data or {}).items():
        if _name in _g and isinstance(_rows, (list, dict)):
            _g[_name] = _rows
        for _obj in list(_g.values()):
            if isinstance(_obj, type) and hasattr(_obj, _name):
                setattr(_obj, _name, _rows)
    def _have(_n):
        if _g.get(_n):
            return True
        return any(isinstance(_o, type) and getattr(_o, _n, None)
                   for _o in list(_g.values()))
    _missing = [n for n in ['_CANON'] if not _have(n)]
    if _missing:
        print("No data provided for: %s. Fetch records from the MCP server "
              "(list_paymentingestionscreening) first and pass them via --data-json."
              % ", ".join(_missing))
        _sys.exit(3)
    print(PaymentIngestionScreening().perform(**_kw))

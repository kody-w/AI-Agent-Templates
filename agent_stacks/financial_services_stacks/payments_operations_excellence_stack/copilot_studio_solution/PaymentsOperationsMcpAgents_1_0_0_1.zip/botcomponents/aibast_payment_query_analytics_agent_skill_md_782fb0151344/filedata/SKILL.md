---
name: paymentqueryanalytics
description: Resolves 'where is my payment?' tracking queries with the real-time status and timeline from the payment platform (records in Microsoft Dataverse), and serves the payments analytics scoreboard — volumes, values, STP rate, holds, and scheme compliance across all rails. Identify a payment by NATURAL reference (PAY- reference or beneficiary name); ask for 'analytics' for the scoreboard; never ask the user for internal identifiers. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# PaymentQueryAnalytics skill

## When to use

- Show Payment Query Analytics for paymentreference PAY-731150.
- Where is the payment to Woodgrove Bank?
- Show me today's payments analytics scoreboard

## Rules (single source of truth)

- The bundled `payment_query_analytics_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_paymentqueryanalytics`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference (e.g. PAY-731150) only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `paymentReference` — Payment to track, e.g. PAY-731150 or 'Woodgrove Bank'. Pass the word: list to see every tracked payment - never ask the user for an id.
- `view` — Set to 'analytics' for the payments scoreboard (optional).

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_paymentqueryanalytics` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 payment_query_analytics_agent.py --data-json '{"_TRACKING": <items from list_paymentqueryanalytics>}' --kwargs-json '{"paymentReference": "PAY-731150 or 'Woodgrove Ban"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `PAY-731150`.

---
name: paymentingestionscreening
description: Ingests payment instructions on any rail (CHAPS, Faster Payments, SEPA, SWIFT), validates them against the scheme rules, and screens every payment in real time against the OFAC, HMT, and EU sanctions lists — holding any potential match with a compliance case reference. Payment records live in Microsoft Dataverse. Identify payments by NATURAL reference: a beneficiary name or a PAY- reference; never ask the user for internal identifiers. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# PaymentIngestionScreening skill

## When to use

- Show Payment Ingestion Screening for paymentreference PAY-731162.
- Screen the payment to Contoso Pharmaceuticals
- Ingest a new payment: GBP 25,000 to Northwind Traders on Faster Payments

## Rules (single source of truth)

- The bundled `payment_ingestion_screening_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_paymentingestionscreening`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference (e.g. LN-73214) only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `paymentReference` — Payment reference or beneficiary name, e.g. PAY-731162 or 'Contoso Pharmaceuticals'. Pass the word: list to see today's ingested payments - never ask the user for an id.
- `beneficiaryName` — Beneficiary for a NEW payment (optional).
- `amount` — Amount for a NEW payment (optional).
- `currency` — Currency for a NEW payment: GBP, EUR, USD (optional).
- `rail` — Rail for a NEW payment: CHAPS, Faster Payments, SEPA, or SWIFT (optional).

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_paymentingestionscreening` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 payment_ingestion_screening_agent.py --data-json '{"_CANON": <items from list_paymentingestionscreening>}' --kwargs-json '{"paymentReference": "PAY-731162 or 'Contoso Pharm"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `PAY-731205`.

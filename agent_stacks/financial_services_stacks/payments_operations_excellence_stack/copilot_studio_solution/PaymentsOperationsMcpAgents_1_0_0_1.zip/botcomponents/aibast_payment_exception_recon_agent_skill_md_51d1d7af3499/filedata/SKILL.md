---
name: paymentexceptionrecon
description: Works STP failures and reconciliation breaks, all held in Microsoft Dataverse. With no inputs it lists the open exception queue (each with its cause analysis and suggested repair action) plus the unreconciled nostro items; given a PAY- or NOS- reference it returns the full analysis; 'repair' applies the suggested fix and confirms STP on retry. Identify items by NATURAL reference; never ask the user for internal identifiers. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# PaymentExceptionRecon skill

## When to use

- Show Payment Exception Recon for reference PAY-731205.
- Which STP exceptions are open right now?
- Repair PAY-731205

## Rules (single source of truth)

- The bundled `payment_exception_recon_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_paymentexceptionrecon`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference (e.g. PAY-731205) only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `reference` — Exception or nostro reference, e.g. PAY-731205 or NOS-4471, or a beneficiary name. Pass the word: list to see all open items - never ask the user for an id.
- `action` — Set to 'repair' to apply the suggested repair action (optional).

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_paymentexceptionrecon` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 payment_exception_recon_agent.py --data-json '{"_EXCEPTIONS": <items from list_paymentexceptionrecon>}' --kwargs-json '{"reference": "PAY-731205 or NOS-4471, or a"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `PAY-731205`.

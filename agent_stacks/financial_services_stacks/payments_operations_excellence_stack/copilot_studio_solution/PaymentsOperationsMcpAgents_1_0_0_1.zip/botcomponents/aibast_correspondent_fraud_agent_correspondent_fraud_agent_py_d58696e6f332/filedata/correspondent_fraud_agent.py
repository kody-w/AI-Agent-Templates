"""Correspondent Banking Management & Fraud Prevention — steps 5-6 of the
Payments Operations Excellence process flow.

Step 5 — Correspondent Banking Management: Correspondent banking
relationship data and limit monitoring is tracked, with alerts for limit
breaches and nostro funding requirements. (Copilot Studio)

Step 6 — Fraud Prevention: Transaction-level fraud indicators are assessed
by Azure AI before payment release. Suspicious payments trigger a customer
verification journey. (Azure AI, Copilot Studio)

Fraud rules are REAL and deterministic: a pre-release fraud score >= 0.25
HOLDS the payment and triggers the verification journey; below releases.
The limit board ties to the reconciliation agent's nostro items (JPMorgan
USD top-up, Deutsche Bank EUR). Data home: Microsoft Dataverse.
"""
try:
    from agents.basic_agent import BasicAgent
except ImportError:
    class BasicAgent:
        def __init__(self, name, metadata):
            self.name, self.metadata = name, metadata

_CORRESPONDENTS = []  # data arrives at runtime from the MCP server (--data-json); the connector is the single source of truth

_FRAUD = []  # data arrives at runtime from the MCP server (--data-json); the connector is the single source of truth

_HOLD_AT = 0.25


class CorrespondentFraudMonitor(BasicAgent):
    CAPIR = {"binding": {"system": "Microsoft Dataverse", "table": "accounts"}}
    TRIGGERS = [
        "Show Correspondent Fraud Monitor for view limits",
        "Run the pre-release fraud assessment for PAY-731130",
        "Which correspondent banks are approaching their limits?",
    ]
    RESPONSE = ("Present records as plain text fields. NEVER invent, guess, "
                "or fabricate URLs, deep links, or Power Apps/Power BI links "
                "— the packaged demo data contains no links. Refer to records "
                "by their plain reference (e.g. PAY-731130) only. Keep "
                "answers under ~120 words, professional markdown, no emojis.")
    SYNTHETIC_DATA = list(_CORRESPONDENTS)

    def __init__(self):
        self.name = "CorrespondentFraudMonitor"
        self.metadata = {
            "name": self.name,
            "description": (
                "Monitors correspondent banking limits and nostro funding "
                "from the correspondent workspace in Microsoft Dataverse "
                "(flagging limit breaches and top-up needs), and runs the "
                "Azure AI pre-release fraud assessment — a score of 0.25 or "
                "higher holds the payment and triggers the customer "
                "verification journey. Ask for the limit board, or name a "
                "payment (PAY- reference or beneficiary) to assess it; "
                "never ask the user for internal identifiers."),
            "parameters": {
                "type": "object",
                "properties": {
                    "view": {
                        "type": "string",
                        "description": ("Set to 'limits' for the "
                                        "correspondent limit and nostro "
                                        "funding board. Pass the word: list "
                                        "for the same view - never ask the "
                                        "user for an id.")},
                    "paymentReference": {
                        "type": "string",
                        "description": ("Payment to fraud-assess before "
                                        "release, e.g. PAY-731130 or a "
                                        "beneficiary name (optional).")},
                },
                "required": [],
            },
        }
        super().__init__(self.name, self.metadata)

    def perform(self, **kwargs):
        ref = str(kwargs.get("paymentReference") or "").strip()
        low = ref.lower()
        if ref and low not in ("list", "limits"):
            hit = next((f for f in _FRAUD
                        if low == f["paymentReference"].lower()
                        or low in f["beneficiaryName"].lower()), None)
            if not hit:
                names = ", ".join(f["paymentReference"] for f in _FRAUD)
                return (f"No pre-release assessment matches `{ref}`. "
                        f"Assessable payments: {names}.")
            held = hit["fraudScore"] >= _HOLD_AT
            lines = [
                f"## Pre-release fraud assessment — "
                f"{hit['paymentReference']} ({hit['beneficiaryName']})",
                f"- Transaction fraud score (Azure AI): "
                f"**{hit['fraudScore']:.2f}** (hold threshold "
                f"{_HOLD_AT:.2f})",
                "- Indicators assessed: velocity, beneficiary novelty, "
                "device and session signals.",
            ]
            if held:
                lines += [
                    "- **SUSPICIOUS — payment HELD.** Customer verification "
                    "journey triggered (push notification + step-up).",
                    "- Release or cancel on the verification outcome.",
                ]
            else:
                lines += ["- Inside appetite — payment released."]
            return "\n".join(lines)
        lines = ["## Correspondent banking — limits & nostro funding"]
        lines += [f"{i}. **{c['correspondentName']}** ({c['currency']}) — "
                  f"limit utilisation {c['limitUtilisation']:.0%} — "
                  f"{c['limitStatus']} — {c['nostroNote']}"
                  for i, c in enumerate(_CORRESPONDENTS, 1)]
        lines += ["", "JPMorgan USD utilisation has breached the 90% "
                      "early-warning threshold — recommend a USD 40M nostro "
                      "top-up before the New York window. Name a payment to "
                      "run its pre-release fraud assessment."]
        return "\n".join(lines)


if __name__ == "__main__":  # thin-skill entrypoint (generated)
    import argparse as _ap
    import json as _js
    import sys as _sys
    _p = _ap.ArgumentParser(description="Run the CorrespondentFraudMonitor capability on "
                                        "records fetched from the MCP server.")
    _p.add_argument("--data-json", default="{}",
                    help="JSON object mapping dataset names to record arrays "
                         "fetched from the MCP server, e.g. "
                         "'{\"_CORRESPONDENTS\": <items from list_correspondentfraudmonitor>}'")
    _p.add_argument("--kwargs-json", default="{}",
                    help="JSON object of perform() keyword arguments.")
    _a = _p.parse_args()
    try:
        _data = _js.loads(_a.data_json)
        _kw = _js.loads(_a.kwargs_json)
    except Exception as _e:
        print("Invalid JSON argument: %s" % _e)
        _sys.exit(2)
    _g = globals()
    for _name, _rows in (_data or {}).items():
        if _name in _g and isinstance(_rows, (list, dict)):
            _g[_name] = _rows
        for _obj in list(_g.values()):
            if isinstance(_obj, type) and hasattr(_obj, _name):
                setattr(_obj, _name, _rows)
    def _have(_n):
        if _g.get(_n):
            return True
        return any(isinstance(_o, type) and getattr(_o, _n, None)
                   for _o in list(_g.values()))
    _missing = [n for n in ['_CORRESPONDENTS', '_FRAUD'] if not _have(n)]
    if _missing:
        print("No data provided for: %s. Fetch records from the MCP server "
              "(list_correspondentfraudmonitor) first and pass them via --data-json."
              % ", ".join(_missing))
        _sys.exit(3)
    print(CorrespondentFraudMonitor().perform(**_kw))

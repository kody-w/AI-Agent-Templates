---
name: correspondentfraudmonitor
description: Monitors correspondent banking limits and nostro funding from the correspondent workspace in Microsoft Dataverse (flagging limit breaches and top-up needs), and runs the Azure AI pre-release fraud assessment — a score of 0.25 or higher holds the payment and triggers the customer verification journey. Ask for the limit board, or name a payment (PAY- reference or beneficiary) to assess it; never ask the user for internal identifiers. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# CorrespondentFraudMonitor skill

## When to use

- Show Correspondent Fraud Monitor for view limits
- Run the pre-release fraud assessment for PAY-731130
- Which correspondent banks are approaching their limits?

## Rules (single source of truth)

- The bundled `correspondent_fraud_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_correspondentfraudmonitor`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference (e.g. PAY-731130) only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `view` — Set to 'limits' for the correspondent limit and nostro funding board. Pass the word: list for the same view - never ask the user for an id.
- `paymentReference` — Payment to fraud-assess before release, e.g. PAY-731130 or a beneficiary name (optional).

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_correspondentfraudmonitor` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 correspondent_fraud_agent.py --data-json '{"_CORRESPONDENTS": <items from list_correspondentfraudmonitor>}' --kwargs-json '{"paymentReference": "PAY-731130 or a beneficiary"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `Deutsche Bank AG`.

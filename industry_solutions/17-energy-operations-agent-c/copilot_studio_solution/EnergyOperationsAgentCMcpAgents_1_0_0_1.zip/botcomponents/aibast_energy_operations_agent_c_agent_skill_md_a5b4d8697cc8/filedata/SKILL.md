---
name: energyoperationsagentc
description: Deliver real-time insights, automate critical workflows, and enable guided decision making—boosting efficiency while reducing operational and compliance risk for energy organizations. Records live in Microsoft Dataverse (synthetic, no PII). Identify a site by a name or a SITE- reference; pass 'list' to see all — never ask for an id. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# EnergyOperationsAgentC skill

## When to use

- List today's site records.
- Show SITE-10340.
- What is the status of Wingtip Toys?

## Rules (single source of truth)

- The bundled `energy_operations_agent_c_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_energyoperationsagentc`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `reference` — A site reference or a subject name, e.g. SITE-10340 or 'Woodgrove Bank'. Pass 'list' to see every site.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_energyoperationsagentc` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 energy_operations_agent_c_agent.py --data-json '{"_CANON": <items from list_energyoperationsagentc>}' --kwargs-json '{"reference": "SITE-10340 or 'Woodgrove Ban"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `SITE-10340`.

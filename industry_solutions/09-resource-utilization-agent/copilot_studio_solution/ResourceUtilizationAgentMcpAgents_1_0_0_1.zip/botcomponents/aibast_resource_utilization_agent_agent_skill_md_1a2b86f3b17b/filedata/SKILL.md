---
name: resourceutilizationagent
description: Provide intelligent resource analysis and recommendations to maximize billable utilization and reduce costs. Records live in Microsoft Dataverse (synthetic, no PII). Identify a case by a name or a CS- reference; pass 'list' to see all — never ask for an id. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# ResourceUtilizationAgent skill

## When to use

- List today's case records.
- Show CS-10180.
- What is the status of Fourth Coffee?

## Rules (single source of truth)

- The bundled `resource_utilization_agent_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_resourceutilizationagent`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `reference` — A case reference or a subject name, e.g. CS-10180 or 'Margie's Travel'. Pass 'list' to see every case.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_resourceutilizationagent` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 resource_utilization_agent_agent.py --data-json '{"_CANON": <items from list_resourceutilizationagent>}' --kwargs-json '{"reference": "CS-10180 or 'Margie's Travel"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `CS-10180`.

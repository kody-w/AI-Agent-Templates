---
name: accountresearchagent
description: Automate account research and strategy planning to help sellers prepare faster, win more, and elevate deal quality. Records live in Microsoft Dataverse (synthetic, no PII). Identify a opportunity by a name or a OPP- reference; pass 'list' to see all — never ask for an id. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# AccountResearchAgent skill

## When to use

- List today's opportunity records.
- Show OPP-10380.
- What is the status of Contoso?

## Rules (single source of truth)

- The bundled `account_research_agent_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_accountresearchagent`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `reference` — A opportunity reference or a subject name, e.g. OPP-10380 or 'Graphic Design Institute'. Pass 'list' to see every opportunity.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_accountresearchagent` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 account_research_agent_agent.py --data-json '{"_CANON": <items from list_accountresearchagent>}' --kwargs-json '{"reference": "OPP-10380 or 'Graphic Design"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `OPP-10380`.

---
name: omnichannelinventoryagent
description: Deliver real-time cross-channel inventory intelligence to prevent stockouts, reduce overstock, and maximize omnichannel retail performance. Records live in Microsoft Dataverse (synthetic, no PII). Identify a SKU by a name or a SKU- reference; pass 'list' to see all — never ask for an id. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# OmnichannelInventoryAgent skill

## When to use

- List today's SKU records.
- Show SKU-10620.
- What is the status of Coho Vineyard?

## Rules (single source of truth)

- The bundled `omnichannel_inventory_agent_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_omnichannelinventoryagent`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `reference` — A SKU reference or a subject name, e.g. SKU-10620 or 'Lucerne Publishing'. Pass 'list' to see every SKU.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_omnichannelinventoryagent` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 omnichannel_inventory_agent_agent.py --data-json '{"_CANON": <items from list_omnichannelinventoryagent>}' --kwargs-json '{"reference": "SKU-10620 or 'Lucerne Publis"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `SKU-10620`.

"""Month-End Billing Agent — Professional Services, Consulting industry solution (AIBAST).

Automate month-end billing cycles to accelerate invoicing, reduce risk, and ensure audit-ready compliance.

Personas: Finance VP; Billing Manager.
Featured tools: Dynamics 365 ERP, SharePoint, Microsoft Teams.

Synthetic demo data only — no PII (Microsoft fictional companies). Records live
in Microsoft Dataverse. Identify a invoice by NATURAL reference: a name or a
INV- id; never ask the user for an internal id — pass 'list' to see all.
"""
try:
    from agents.basic_agent import BasicAgent
except ImportError:  # portable / standalone
    class BasicAgent:
        def __init__(self, name, metadata):
            self.name, self.metadata = name, metadata

_CANON = []  # data arrives at runtime from the MCP server (--data-json); the connector is the single source of truth


class MonthEndBillingAgent(BasicAgent):
    CAPIR = {"binding": {"system": "Microsoft Dataverse", "table": "accounts"}}
    TRIGGERS = [
        "List today's invoice records.",
        "Show INV-10160.",
        "What is the status of Litware?"
]
    RESPONSE = ("Present records as plain text fields. NEVER invent, guess, or "
                "fabricate URLs, deep links, or Power Apps/Power BI links — the "
                "packaged demo data contains no links. Refer to records by their "
                "plain reference only. Keep answers under ~120 words, "
                "professional markdown, no emojis.")
    SYNTHETIC_DATA = list(_CANON)

    def __init__(self):
        self.name = "MonthEndBillingAgent"
        self.metadata = {
            "name": self.name,
            "description": (
                "Automate month-end billing cycles to accelerate invoicing, reduce risk, and ensure audit-ready compliance. Records live in Microsoft Dataverse (synthetic, no "
                "PII). Identify a invoice by a name or a INV- "
                "reference; pass 'list' to see all — never ask for an id."),
            "parameters": {
                "type": "object",
                "properties": {
                    "reference": {
                        "type": "string",
                        "description": ("A invoice reference or a subject "
                                        "name, e.g. INV-10160 or 'Proseware'. Pass 'list' to "
                                        "see every invoice.")},
                },
                "required": [],
            },
        }
        super().__init__(self.name, self.metadata)

    def _find(self, ref):
        low = ref.lower()
        return [r for r in _CANON if low == r["reference"].lower()
                or low in r["subject"].lower()]

    def perform(self, **kwargs):
        ref = str(kwargs.get("reference") or "").strip()
        if not ref or ref.lower() == "list":
            lines = ["## Month-End Billing Agent — invoice records (Dataverse)"]
            lines += ["%d. **%s** — %s | status: %s | owner: %s"
                      % (n, r["reference"], r["subject"], r["status"], r["owner"])
                      for n, r in enumerate(_CANON, 1)]
            lines.append("")
            lines.append("Name a invoice for its detail.")
            return "\n".join(lines)
        hits = self._find(ref)
        if not hits:
            return "No invoice matches `%s`. Say 'list' to see all." % ref
        r = hits[0]
        return "\n".join([
            "## %s — %s" % (r["reference"], r["subject"]),
            "- Status: **%s**" % r["status"],
            "- Owner: %s" % r["owner"],
            "- Key metric: %s" % r["metric"],
            "- %s" % r["note"],
        ])


if __name__ == "__main__":  # thin-skill entrypoint (generated)
    import argparse as _ap
    import json as _js
    import sys as _sys
    _p = _ap.ArgumentParser(description="Run the MonthEndBillingAgent capability on "
                                        "records fetched from the MCP server.")
    _p.add_argument("--data-json", default="{}",
                    help="JSON object mapping dataset names to record arrays "
                         "fetched from the MCP server, e.g. "
                         "'{\"_CANON\": <items from list_monthendbillingagent>}'")
    _p.add_argument("--kwargs-json", default="{}",
                    help="JSON object of perform() keyword arguments.")
    _a = _p.parse_args()
    try:
        _data = _js.loads(_a.data_json)
        _kw = _js.loads(_a.kwargs_json)
    except Exception as _e:
        print("Invalid JSON argument: %s" % _e)
        _sys.exit(2)
    _g = globals()
    for _name, _rows in (_data or {}).items():
        if _name in _g and isinstance(_rows, (list, dict)):
            _g[_name] = _rows
        for _obj in list(_g.values()):
            if isinstance(_obj, type) and hasattr(_obj, _name):
                setattr(_obj, _name, _rows)
    def _have(_n):
        if _g.get(_n):
            return True
        return any(isinstance(_o, type) and getattr(_o, _n, None)
                   for _o in list(_g.values()))
    _missing = [n for n in ['_CANON'] if not _have(n)]
    if _missing:
        print("No data provided for: %s. Fetch records from the MCP server "
              "(list_monthendbillingagent) first and pass them via --data-json."
              % ", ".join(_missing))
        _sys.exit(3)
    print(MonthEndBillingAgent().perform(**_kw))

---
name: wealthinsightsagent
description: Deliver AI-powered portfolio intelligence to uncover hidden asset opportunities, strengthen client relationships, and drive advisory growth at scale. Records live in Microsoft Dataverse (synthetic, no PII). Identify a case by a name or a CS- reference; pass 'list' to see all — never ask for an id. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# WealthInsightsAgent skill

## When to use

- List today's case records.
- Show CS-10780.
- What is the status of Trey Research?

## Rules (single source of truth)

- The bundled `wealth_insights_agent_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_wealthinsightsagent`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `reference` — A case reference or a subject name, e.g. CS-10780 or 'Adatum'. Pass 'list' to see every case.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_wealthinsightsagent` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 wealth_insights_agent_agent.py --data-json '{"_CANON": <items from list_wealthinsightsagent>}' --kwargs-json '{"reference": "CS-10780 or 'Adatum'. Pass"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `CS-10780`.

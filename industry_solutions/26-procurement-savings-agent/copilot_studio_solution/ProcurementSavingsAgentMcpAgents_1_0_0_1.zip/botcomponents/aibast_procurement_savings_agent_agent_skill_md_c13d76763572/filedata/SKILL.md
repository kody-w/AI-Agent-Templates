---
name: procurementsavingsagent
description: Identify and optimize savings opportunities across vendors, contracts, and purchasing cycles to reduce costs and increase procurement efficiency. Records live in Microsoft Dataverse (synthetic, no PII). Identify a order by a name or a PO- reference; pass 'list' to see all — never ask for an id. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# ProcurementSavingsAgent skill

## When to use

- List today's order records.
- Show PO-10520.
- What is the status of Adatum?

## Rules (single source of truth)

- The bundled `procurement_savings_agent_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_procurementsavingsagent`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `reference` — A order reference or a subject name, e.g. PO-10520 or 'Fabrikam'. Pass 'list' to see every order.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_procurementsavingsagent` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 procurement_savings_agent_agent.py --data-json '{"_CANON": <items from list_procurementsavingsagent>}' --kwargs-json '{"reference": "PO-10520 or 'Fabrikam'. Pass"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `PO-10520`.

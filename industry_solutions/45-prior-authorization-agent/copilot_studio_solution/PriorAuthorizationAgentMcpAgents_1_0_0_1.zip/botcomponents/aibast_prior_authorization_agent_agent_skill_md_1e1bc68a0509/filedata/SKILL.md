---
name: priorauthorizationagent
description: Automate insurance approval workflows to accelerate authorization processes, improve documentation accuracy, and reduce care delays. Records live in Microsoft Dataverse (synthetic, no PII). Identify a record by a name or a PT- reference; pass 'list' to see all — never ask for an id. The skill runs the bundled Python script (the same deterministic logic that powers the classic agent) and prints the finished answer.
---

# PriorAuthorizationAgent skill

## When to use

- List today's record records.
- Show PT-10900.
- What is the status of Fabrikam?

## Rules (single source of truth)

- The bundled `prior_authorization_agent_agent.py` script IS the capability — run it, never compute by hand, never write your own code for this task.
- Data comes ONLY from the MCP data server (`list_priorauthorizationagent`); fetch it first, every time — the script refuses to run without it.
- Present records as plain text fields. NEVER invent, guess, or fabricate URLs, deep links, or Power Apps/Power BI links — the packaged demo data contains no links. Refer to records by their plain reference only. Keep answers under ~120 words, professional markdown, no emojis.

## Workflow

### 1. Gather the inputs

- `reference` — A record reference or a subject name, e.g. PT-10900 or 'Northwind Traders'. Pass 'list' to see every record.

Never ask the user for internal identifiers — pass the natural reference you were given (a name works), or pass the word `list` to see every record.

### 2. Fetch the records from the MCP server

Call the `list_priorauthorizationagent` tool on the MCP data server (add a filter argument to narrow, or call it bare for every record). The MCP server is the SINGLE SOURCE OF TRUTH — the script carries no data of its own.

### 3. Run the bundled script

```bash
python3 prior_authorization_agent_agent.py --data-json '{"_CANON": <items from list_priorauthorizationagent>}' --kwargs-json '{"reference": "PT-10900 or 'Northwind Trade"}'
```

Pass the MCP items array through --data-json unchanged. The script prints finished markdown. Empty kwargs (`'{}'`) shows the default queue/list view.

### 4. Report the result

Relay the script's markdown to the user (trim to one screen). Suggest the natural next step the output names.

## Notes

- Data is synthetic and deterministic; keys look like `PT-10900`.
